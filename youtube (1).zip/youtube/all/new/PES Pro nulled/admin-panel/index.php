<?php
define('BASEPATH', true);
define('IS_ADMIN', true);
include('../system/init.php');

/* Define allowed pages */
$action = array(
		'users' => 1,
		'blacklist' => 1,
		'adcodes' => 1,
		'bank' => 1,
		'settings' => 1,
		'sites' => 1,
		'sellcoins' => 1,
		'packs' => 1,
		'p_packs' => 1,
		'coupons' => 1,
		'sales' => 1,
		'search' => 1,
		'faq' => 1,
		'blog' => 1,
		'requests' => 1,
		'refset' => 1,
		'regset' => 1,
		'surfset' => 1,
		'vipset' => 1,
		'newsletter' => 1,
		'dashboard' => 1,
		'gateways' => 1,
		'transfers' => 1,
		'reports' => 1,
		'captcha' => 1,
		'fbset' => 1,
		'twset' => 1,
		'ytset' => 1,
		'top_users' => 1,
		'banners' => 1,
		'proofs' => 1,
		'mailset' => 1,
		'levels' => 1,
		'jobs' => 1,
		'offers' => 1,
		'offerwalls' => 1,
		'cashmining' => 1,
		'rewards' => 1
	);

include('sections/core.php');
?>
<html>
<head><title>PES Pro - Admin Panel</title>
	<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<meta name="author" content="MafiaNet (c) MN-Shop.com">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/fonts/font-awesome.css">
    <!--[if IE 8]><link rel="stylesheet" href="css/fonts/font-awesome-ie7.css"><![endif]-->
    <link rel="stylesheet" href="css/external/jquery.css">
    <link rel="stylesheet" href="css/elements.css">

	<!-- Load Javascript -->
    <script src="//code.jquery.com/jquery-1.10.2.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/libs/jquery-1.10.2.min.js"><\/script>')</script>
    <script src="//code.jquery.com/jquery-migrate-1.2.1.min.js"></script>
    <script>window.jQuery || document.write('<script src="js/libs/jquery-migrate-1.2.1.min.js"><\/script>')</script>
    <script src="//code.jquery.com/ui/1.9.1/jquery-ui.min.js"></script>
    <script>window.jQuery.ui || document.write('<script src="js/libs/jquery-ui-1.9.1.min.js"><\/script>')</script>
    <!--[if gt IE 8]><!-->
    <script src="//cdnjs.cloudflare.com/ajax/libs/lodash.js/0.8.2/lodash.min.js"></script>
    <script>window._ || document.write('<script src="js/libs/lo-dash.min.js"><\/script>')</script>
    <!--<![endif]-->
    <!--[if lt IE 9]><script src="//documentcloud.github.com/underscore/underscore.js"></script><![endif]-->
    <script src="//cdnjs.cloudflare.com/ajax/libs/require.js/2.0.6/require.min.js"></script>
    <script>window.require || document.write('<script src="js/libs/require-2.0.6.min.js"><\/script>')</script>
    <script type="text/javascript">
        window.WebFontConfig = {
            google: { families: [ 'PT Sans:400,700' ] },
            active: function(){ $(window).trigger('fontsloaded') }
        };
    </script>
    <script defer async src="//ajax.googleapis.com/ajax/libs/webfont/1.0.28/webfont.js"></script>
    <script src="js/mylibs/polyfills/modernizr-2.6.1.min.js"></script>
    <!--[if lt IE 9]><script src="js/mylibs/polyfills/selectivizr.js"></script><![endif]-->
    <!--[if lt IE 10]><script src="js/mylibs/polyfills/excanvas.js"></script><![endif]-->
    <!--[if lt IE 10]><script src="js/mylibs/polyfills/classlist.js"></script><![endif]-->
    <script src="js/mylibs/jquery.lib.js"></script>
    <script src="js/mylibs/fullstats/jquery.css-transform.js"></script>
    <script src="js/mylibs/fullstats/jquery.animate-css-rotate-scale.js"></script>
    <script src="js/mylibs/forms/jquery.validate.js"></script>
    <script src="js/pespro.js"></script>
    <script src="js/plugins.js"></script>
    <script src="js/script.js"></script>
</head>
<body>
	<div id="loading-overlay"></div>
    <div id="loading">
        <span>Loading...</span>
    </div>
	<section id="toolbar">
		<div class="container_12">
			<div class="left">
				<ul class="breadcrumb">
					<li><a href="<?=$config['secure_url']?>/admin-panel/">PES Admin</a></li>
				</ul>
			</div>
			<div class="right">
				<ul>
					<li><a href="http://mn-shop.com" target="_blank"><span id="time"><?=date('H:i:s')?></span>Server Time</a></li>
                    <li class="space"></li>
					<li><a href="<?=$config['secure_url']?>">View Website</a></li>
					<li class="red"><a href="<?=$config['secure_url']?>/?logout">Logout</a></li>
				</ul>
			</div>
			<div class="phone">
                <li><a class="navigation" href="#"><span class="icon icon-list"></span></a></li>
            </div>
		</div>
	</section>
	<header class="container_12"><br></header>
	<div role="main" id="main" class="container_12 clearfix">
		<section class="toolbar">
			<div class="user">
                <div class="avatar">
                    <img src="//www.gravatar.com/avatar/<?=md5(strtolower(trim($data['email'])))?>?s=28">
                </div>
                <span><?=$data['login']?></span>
                <ul>
                    <li><a href="index.php?x=users&edit=<?=$data['id']?>">Account Settings</a></li>
                    <li><a href="<?=$config['secure_url']?>">View Website</a></li>
                    <li class="line"></li>
                    <li><a href="<?=$config['secure_url']?>/?logout">Logout</a></li>
                </ul>
            </div>
			<ul class="shortcuts">
				<li>
                    <a href="javascript:void(0);"><span class="icon i24_user-business"></span></a>
                    <div class="large">
                        <h3>Create an user account</h3>
						<form method="post" action="index.php?x=users">
							<button class="button flat left grey" onclick="$(this).parent().fadeToggle($$.config.fxSpeed).parent().removeClass('active')">Close</button>
							<button type="submit" name="user_add" class="button flat right">Create</button>
							<div class="content">
								<div class="full grid">
									<div class="row no-bg">
										<p class="_50 small">
											<label for="user_username">Username</label>
											<input type="text" name="user_username" id="user_username" placeholder="John_Doe" />
										</p>
										<p class="_50 small">
											<label for="user_admin">Type</label>
											<select name="user_admin" id="user_admin">
												<option value="0">Member</option>
												<option value="1">Admin</option>
											</select>
										</p>
									</div>
									<div class="row no-bg">
										<p class="_50 small">
											<label for="user_email">Email Address</label>
											<input type="text" name="user_email" id="user_email" placeholder="email@domain.com" />
										</p>
										<p class="_50 small">
											<label for="user_email_2">Repeat Email</label>
											<input type="text" name="user_email_2" id="user_email_2" placeholder="email@domain.com" />
										</p>
									</div>
									<div class="row no-bg">
										<p class="_50 small">
											<label for="user_password">Password</label>
											<input type="password" name="user_password" id="user_password" placeholder="X8df!90EO" />
										</p>
										<p class="_50 small">
											<label for="user_password_2">Repeat Password</label>
											<input type="password" name="user_password_2" id="user_password_2" placeholder="X8df!90EO" />
										</p>
									</div>
									<div class="row no-bg">
										<p class="_50 small">
											<label for="user_gender">Gender</label>
											<select name="user_gender" id="user_gender">
												<option value="0">Choose...</option>
												<option value="1">Male</option>
												<option value="2">Female</option>
											</select>
										</p>
										<p class="_50 small">
											<label for="user_country">Country</label>
											<select name="user_country" id="user_country" class="search" data-placeholder="Select Country">
												<?php
													$countries = $db->QueryFetchArrayAll("SELECT country,id FROM `list_countries` ORDER BY country ASC"); 
													echo '<option value="0">Choose...</option>';
													foreach($countries as $country){ 
														echo '<option value="'.$country['id'].'">'.$country['country'].'</option>';
													}
												?>
											</select>
										</p>
									</div>
								</div>
							</div>
                        </form>
					</div>
                </li>
			</ul>
		</section>
		<aside>
			<div class="top">
				<nav><ul class="collapsible accordion">
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/dashboard.png" alt="" height="16" width="16">Statistics</a>
						<ul>
							<li><a href="index.php"><span class="icon icon-arrow-right"></span> Dashboard</a></li>
							<li><a href="index.php?x=transfers"><span class="icon icon-arrow-right"></span> Coins Transfers</a></li>
							<li><a href="index.php?x=offers"><span class="icon icon-arrow-right"></span> Completed Offers</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/coins.png" alt="" height="16" width="16">Bank</a>
						<ul>
							<li><a href="index.php?x=sales"><span class="icon icon-arrow-right"></span> Added Funds</a></li>
							<li><a href="index.php?x=sales&pending"><span class="icon icon-arrow-right"></span> Added funds pending</a></li>
							<li><a href="index.php?x=requests"><span class="icon icon-arrow-right"></span> Payment Requests</a></li>
						</ul>
					</li>
					<?php if($config['allow_withdraw'] == 1){ ?>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/ads.png" alt="" height="16" width="16">Payment Proofs <span class="badge" id="pending_proofs" style="display:none">0</span></a>
						<ul>
							<li><a href="index.php?x=proofs"><span class="icon icon-arrow-right"></span> Pending Proofs</a></li>
							<li><a href="index.php?x=proofs&aproved"><span class="icon icon-arrow-right"></span> Approved Proofs</a></li>
						</ul>
					</li>
					<?php } ?>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/users.png" alt="" height="16" width="16">Users</a>
						<ul>
							<li><a href="index.php?x=users"><span class="icon icon-arrow-right"></span> All Users</a></li>
							<li><a href="index.php?x=top_users"><span class="icon icon-arrow-right"></span> Top 20 Users</a></li>
							<li><a href="index.php?x=users&today"><span class="icon icon-arrow-right"></span> Registered Today</a></li>
							<li><a href="index.php?x=users&online"><span class="icon icon-arrow-right"></span> Online Users</a></li>
							<li><a href="index.php?x=users&premium"><span class="icon icon-arrow-right"></span> VIP Users</a></li>
							<li><a href="index.php?x=users&unverified"><span class="icon icon-arrow-right"></span> Unconfirmed Email</a></li>
							<li><a href="index.php?x=users&banned"><span class="icon icon-arrow-right"></span> Banned Users</a></li>
							<li><a href="index.php?x=users&countries"><span class="icon icon-arrow-right"></span> Countries Overview</a></li>
							<li><a href="index.php?x=users&multi_accounts"><span class="icon icon-arrow-right"></span> Multiple Accounts</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/mining.png" alt="" height="16" width="16">Mining Coins</a>
						<ul>
							<li><a href="index.php?x=cashmining&users"><span class="icon icon-arrow-right"></span> Active Users</a></li>
							<li><a href="index.php?x=cashmining"><span class="icon icon-arrow-right"></span> Settings</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/jobs.png" alt="" height="16" width="16">Jobs <span class="badge" id="pending_jobs" style="display:none">0</span></a>
						<ul>
							<li><a href="index.php?x=jobs"><span class="icon icon-arrow-right"></span> Jobs</a></li>
							<li><a href="index.php?x=jobs&add"><span class="icon icon-arrow-right"></span> Add Job</a></li>
							<li><a href="index.php?x=jobs&pending"><span class="icon icon-arrow-right"></span> Completed Jobs</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/medal.png" alt="" height="16" width="16">Rewards</a>
						<ul>
							<li><a href="index.php?x=rewards"><span class="icon icon-arrow-right"></span> Rewards</a></li>
							<li><a href="index.php?x=rewards&claims"><span class="icon icon-arrow-right"></span> Claimed Rewards</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/levels.png" alt="" height="16" width="16">Levels (daily bonus)</a>
						<ul>
							<li><a href="index.php?x=levels"><span class="icon icon-arrow-right"></span> Levels</a></li>
							<li><a href="index.php?x=levels&add"><span class="icon icon-arrow-right"></span> Add Level</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/pages.png" alt="" height="16" width="16">Pages</a>
						<ul>
							<?php
								foreach($module_list as $module)
								{
									$name = hook_filter($module.'_info', 'name');
									
									if($name != 'name')
									{
										echo '<li><a href="index.php?x=sites&s='.$module.'"><span class="icon icon-arrow-right"></span> '.$name.'</a></li>';
									}
								}
							?>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/elements/alert-boxes/error.png" alt="" height="16" width="16">Blacklists</a>
						<ul>
							<li><a href="index.php?x=blacklist"><span class="icon icon-arrow-right"></span> Emails</a></li>
							<li><a href="index.php?x=blacklist&type=2"><span class="icon icon-arrow-right"></span> Websites</a></li>
							<li><a href="index.php?x=blacklist&type=3"><span class="icon icon-arrow-right"></span> IP Addresses</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/coins.png" alt="" height="16" width="16">Coins packs</a>
						<ul>
							<li><a href="index.php?x=packs"><span class="icon icon-arrow-right"></span> Coins Packs</a></li>
							<li><a href="index.php?x=sellcoins"><span class="icon icon-arrow-right"></span> Users Packs</a></li>
							<li><a href="index.php?x=packs&settings"><span class="icon icon-arrow-right"></span> Settings</a></li>
						</ul>
					</li>
					<?php
						if($config['vip_purchase'] != 1) {
					?>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/medal.png" alt="" height="16" width="16">VIP Packs</a>
						<ul>
							<li><a href="index.php?x=p_packs"><span class="icon icon-arrow-right"></span> Packs</a></li>
						</ul>
					</li>
					<?php } ?>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/ads.png" alt="" height="16" width="16">Banner Ads</a>
						<ul>
							<li><a href="index.php?x=banners"><span class="icon icon-arrow-right"></span> Manage Banners</a></li>
							<li><a href="index.php?x=banners&packs"><span class="icon icon-arrow-right"></span> Manage Packs</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/cards.png" alt="" height="16" width="16">Coupons</a>
						<ul>
							<li><a href="index.php?x=coupons"><span class="icon icon-arrow-right"></span> Coupons</a></li>
							<li><a href="index.php?x=coupons&add"><span class="icon icon-arrow-right"></span> Add Coupon</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/report.png" alt="" height="16" width="16">Reports <span class="badge" id="pending_reports" style="display:none">0</span></a>
						<ul>
							<li><a href="index.php?x=reports"><span class="icon icon-arrow-right"></span> Reported Pages</a></li>
							<li><a href="index.php?x=reports&completed"><span class="icon icon-arrow-right"></span> Checked Reports</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/balloon.png" alt="" height="16" width="16">Blog</a>
						<ul>
							<li><a href="index.php?x=blog"><span class="icon icon-arrow-right"></span> Manage Blog</a></li>
							<li><a href="index.php?x=blog&add"><span class="icon icon-arrow-right"></span> Add Blog</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/question.png" alt="" height="16" width="16">FAQ</a>
						<ul>
							<li><a href="index.php?x=faq"><span class="icon icon-arrow-right"></span> Manage FAQ</a></li>
							<li><a href="index.php?x=faq&add"><span class="icon icon-arrow-right"></span> Add</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/plus.png" alt="" height="16" width="16">Other Options</a>
						<ul>
							<li><a href="index.php?x=newsletter"><span class="icon icon-arrow-right"></span> Send Newsletter</a></li>
							<li><a href="index.php?x=adcodes"><span class="icon icon-arrow-right"></span> Advertisments</a></li>
						</ul>
					</li>
					<li>
						<a href="javascript:void(0);"><img src="img/icons/packs/fugue/16x16/sett.png" alt="" height="16" width="16">Settings</a>
						<ul>
							<li><a href="index.php?x=settings"><span class="icon icon-arrow-right"></span> General Settings</a></li>
							<li><a href="index.php?x=regset"><span class="icon icon-arrow-right"></span> Users Settings</a></li>
							<li><a href="index.php?x=bank"><span class="icon icon-arrow-right"></span> Bank Settings</a></li>
							<li><a href="index.php?x=vipset"><span class="icon icon-arrow-right"></span> VIP Settings</a></li>
							<li><a href="index.php?x=mailset"><span class="icon icon-arrow-right"></span> Mailing Settings</a></li>
							<li><a href="index.php?x=gateways"><span class="icon icon-arrow-right"></span> Payment Gateways</a></li>
							<li><a href="index.php?x=captcha"><span class="icon icon-arrow-right"></span> Captcha Settings</a></li>
							<li><a href="index.php?x=refset"><span class="icon icon-arrow-right"></span> Affiliate Settings</a></li>
							<li><a href="index.php?x=fbset"><span class="icon icon-arrow-right"></span> Facebook Settings</a></li> 
							<li><a href="index.php?x=twset"><span class="icon icon-arrow-right"></span> Twitter Settings</a></li>
							<li><a href="index.php?x=ytset"><span class="icon icon-arrow-right"></span> Youtube Settings</a></li>
							<li><a href="index.php?x=surfset"><span class="icon icon-arrow-right"></span> Surf Settings</a></li>
							<li><a href="index.php?x=offerwalls"><span class="icon icon-arrow-right"></span> OfferWalls Settings</a></li>
						</ul>
					</li>
				</ul></nav>		
			</div>
			<div class="bottom sticky">
				<div class="divider"></div>
				<div style="font-size:11px;margin:10px 15px"><b>Script Version:</b> <span style="color:green;float:right"><strong><?=$config['version']?></strong></span></div>
				<div style="font-size:11px;margin:10px 15px"><b>Latest Version:</b> <span style="float:right"><strong style="color:blue" id="latest_version"><?=$config['version']?></strong></span></div>
			</div>
		</aside>
	<?php
		include('sections/'.$page_name.'.php'); 
	?>
	</div>
	<script> $$.loaded(); $(document).ready(function(){var e='<?=$config['version']?>';function getVersion(){$.ajax({url:"index.php?version",timeout:7500,success:function(b){$("#latest_version").html(b);if(b!=""){if(b>e){$("#version_alert").show()}}},error:function(b){$("#latest_version").html(e)}})}function getStats(){$.getJSON("../system/ajax.php?a=adminStats",function(a){$.each(a,function(d,c){switch(c["class"]){case"pending_proofs":$("#pending_proofs").html(c.data).fadeIn("slow");break;case"pending_reports":$("#pending_reports").html(c.data).fadeIn("slow");break; case"pending_jobs":$("#pending_jobs").html(c.data).fadeIn("slow");break}});setInterval(getStats(),2500)})}getStats();setTimeout(getVersion(),1000);startTime()}); </script>
	<footer class="container_12">
		<ul class="grid_6">
			<li><a href="http://cashmining.xyz/" target="_blank">CashMining</a></li>
			<li><a href="http://pespro.xyz/" target="_blank">PES Pro</a></li>
			<li><a href="http://forum.mn-shop.com/" target="_blank">Support Forum</a></li>
		</ul>
		<span class="grid_6">&copy; <?=date('Y')?> <a href="http://mn-shop.com/" target="_blank">MafiaNet</a></span>
	</footer>
</body>
</html>