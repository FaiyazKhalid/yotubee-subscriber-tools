<?php
	if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
?>
<section id="content" class="container_12">
	<?php
		if(!isset($_GET['users'])) {
			// Connect Function
			function connect($hash_key, $oid, $cm_domain, $domain = '') {
				if(empty($domain)){
					$domain = str_replace("www.","", $_SERVER['HTTP_HOST']);
				}

				$posts = array('a' => 'connect', 'product' => 'pespro', 'hash' => $hash_key, 'oid' => $oid, 'domain' => $domain);
				$fields = '';
				foreach($posts as $key => $value) {
					$fields .= $key . '=' . $value . '&'; 
				}
				rtrim($fields, '&');

				$ch = curl_init();
				curl_setopt($ch, CURLOPT_URL, 'http://'.trim($cm_domain).'/system/integration.php');
				curl_setopt($ch, CURLOPT_POST, count($posts));
				curl_setopt($ch, CURLOPT_POSTFIELDS, $fields);
				curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
				$result = curl_exec($ch);
				curl_close($ch);

				return $result;
			}
			
			$message = '<div id="status"></div>';
			if(isset($_POST['integrate'])){
				$posts = $db->EscapeString($_POST['set']);
				
				$connect = connect($posts['cm_key'], $posts['cm_id'], $posts['cm_domain']);
				if(empty($connect)){
					$message = '<div class="alert error"><span class="icon"></span><strong>ERROR!</strong> We couldn\'t connect to CM System. Make sure CashMining is installed on provided domain name!</div>';
				} else {
					$connect = json_decode($connect, true);
					
					if($connect['status'] != 'valid'){
						$message = '<div class="alert error"><span class="icon"></span><strong>ERROR!</strong> '.$connect['message'].'</div>';
					} else {
						$db->Query("UPDATE `site_config` SET `config_value`='".$db->EscapeString($connect['token'])."' WHERE `config_name`='cm_token'");
						foreach ($posts as $key => $value){
							if($config[$key] != $value){
								$db->Query("UPDATE `site_config` SET `config_value`='".$value."' WHERE `config_name`='".$key."'");
								$config[$key] = $db->EscapeString($value);
							}
						}
						
						$message = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> CashMining was successfully connected!</div>';
					}
				}
			}
			
			if(isset($_POST['submit'])){
				$posts = $db->EscapeString($_POST['set2']);
				foreach ($posts as $key => $value){
					if($config[$key] != $value){
						$db->Query("UPDATE `site_config` SET `config_value`='".$value."' WHERE `config_name`='".$key."'");
						$config[$key] = $value;
					}
				}
				
				$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
			}
	?>
		<div class="grid_12"><?=$message?>
		<div class="grid_6">
			<form action="" method="post" class="box">
				<div class="header">
					<h2>Connect to your CashMining Website</h2>
				</div>
				<div class="content">
					<div class="row">
						<label><strong>Domain name</strong><small>Enter domain name of your CashMining website</small></label>
						<div><input type="text" name="set[cm_domain]" value="<?=$config['cm_domain']?>" placeholder="domain.tld" required="required" onchange="checkCM(this.value)" /></div>
					</div>
					<div class="row">
						<label><strong>CM ID</strong><small>Enter your CashMining ID</small></label>
						<div><input type="text" name="set[cm_id]" value="<?=$config['cm_id']?>" placeholder="123456" required="required" /></div>
					</div>
					<div class="row">
						<label><strong>CM Hash Key</strong><small>Enter your CashMining Hash Key</small></label>
						<div><input type="text" name="set[cm_key]" value="<?=$config['cm_key']?>" placeholder="692c5220117540c599d9a3d57569c52e" required="required" /></div>
					</div>
				</div>
				<div class="actions">
					<div class="right">
						<input type="submit" name="integrate" value="Connect" />
					</div>
				</div>
			</form>
			<form action="" method="post" class="box">
				<div class="header">
					<h2>Settings</h2>
				</div>
				<div class="content">
					<div class="row">
						<label><strong>Reward</strong><small>How many coins does user receive every minute</small></label>
						<div><input type="text" name="set2[mining_reward]" value="<?=$config['mining_reward']?>" placeholder="1" required="required" /></div>
					</div>
				</div>
				<div class="actions">
					<div class="right">
						<input type="submit" name="submit" value="Submit" />
					</div>
				</div>
			</form>
		</div>
		<div class="grid_6">
			<div class="box">
				<div class="header">
					<h2>Integration Instructions</h2>
				</div>
				<div class="content">
					<p>If you want to connect this website with your <a href="http://buy.cashmining.xyz" target="_blank">CashMining</a> website, please complete the fields as described.</p>
					<p><b>Domain name</b> = Here you have to add your domain name (eg. <i>domain.tld</i>) of your CashMining website</p>
					<p><b>CM ID</b> = Here you have to add your CashMining ID from your CashMining website -> Admin Panel -> Settings -> Connection Settings </p>
					<p><b>CM Hash Key</b> = Here you have to add your CashMining Hash Key from your CashMining website -> Admin Panel -> Settings -> Connection Settings</p>
					<p><font color="red"><b>ATTENTION: If you're not using valid licenses for PES Pro and CashMining, you won't be able to integrate them!</b></font></p>
				</div>
			</div>
		</div>
	<?php
		} else {
			$total_pages = $db->QueryGetNumRows("SELECT * FROM `users_mining` WHERE `last_activity`>='".(time()-70)."'");
			include_once('../system/libs/apaginate.php');
			$page = (isset($_GET['p']) ? $_GET['p'] : '');
			$limit = 20;
			$start = (is_numeric($page) && $page > 0 ? ($page-1)*$limit : 0);
			
			$users = $db->QueryFetchArrayAll("SELECT a.*, b.login FROM users_mining a LEFT JOIN users b ON b.id = a.uid WHERE a.last_activity >= '".(time()-70)."' ORDER BY a.last_activity DESC LIMIT ".$start.",".$limit);
	?>
		<h1 class="grid_12">Users Mining (<?=number_format($total_pages)?>)</h1>
		<div class="grid_12">
			<div class="box">
				<table class="styled">
					<thead>
						<tr>
							<th>User</th>
							<th>Minutes Today</th>
							<th>Total Minutes</th>
							<th>Today Coins</th>
							<th>Total Coins</th>
							<th>Last Coin Received</th>
						</tr>
					</thead>
					<tbody>
					<?php
						if($total_pages == 0) {
							echo '<tr><td colspan="6"><center>There is no user mining right now!</center></td></tr>';
						}
					
						foreach($users as $user){
					?>	
						<tr>
							<td><a href="index.php?x=users&edit=<?=$user['uid']?>"><?=$user['login']?></a></td>
							<td><?=number_format($user['today_minutes'])?> minutes</td>
							<td><?=number_format($user['total_minutes'])?> minutes</td>
							<td><?=number_format($user['today_coins'])?> coins</td>
							<td><?=number_format($user['total_coins'])?> coins</td>
							<td><?=date('d M Y - H:i:s', $user['last_activity'])?></td>
						</tr>
					<?php }?>
					</tbody>
				</table>
				<?php if($total_pages > $limit){ ?>
				<div class="dataTables_wrapper">
					<div class="footer">
						<div class="dataTables_paginate paging_full_numbers">
							<a class="first paginate_button" href="<?=GetHref('p=1')?>">First</a>
							<?=(($pagina <= 1 || $pagina == '') ? '<a class="previous paginate_button paginate_button_disabled">&laquo;</a>' : '<a class="previous paginate_button" href="'.GetHref('p='.($pagina-1)).'">&laquo;</a>')?>
							<span><?=$pagination?></span>
							<?=(($pagina >= $lastpage) ? '<a class="next paginate_button paginate_button_disabled">&raquo;</a>' : '<a class="next paginate_button" href="'.GetHref('p='.($pagina == 0 ? 2 : $pagina+1)).'">&raquo;</a>')?>
							<a class="last paginate_button" href="<?=GetHref('p='.$lastpage)?>">Last</a>
						</div>
					</div>
				</div>
				<?php } ?>
			</div>
		</div>
	<?php } ?>
</section>