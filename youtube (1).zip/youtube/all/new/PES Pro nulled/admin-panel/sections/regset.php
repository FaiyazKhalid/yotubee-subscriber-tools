<?php
	if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
	$mesaj = '';
	if(isset($_POST['submit'])){
		$posts = $db->EscapeString($_POST['set']);
		foreach ($posts as $key => $value){
			if($config[$key] != $value){
				if($key == 'auto_country'){
					$value = ($value > 1 ? 1 : ($value < 0 ? 0 : $value));
				}

				$db->Query("UPDATE `site_config` SET `config_value`='".$value."' WHERE `config_name`='".$key."'");
				$config[$key] = $value;
			}
		}
		
		$mesaj = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
	}
?>
<section id="content" class="container_12 clearfix"><?=$mesaj?>
	<div class="grid_6">
		<form method="post" class="box">
			<div class="header">
				<h2>Registration Settings</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>Registration</strong></label>
					<div><select name="set[reg_status]"><option value="0">Enabled</option><option value="1"<?=($config['reg_status'] != 0 ? ' selected' : '')?>>Disabled</option></select></div>
				</div>
				<div class="row">
					<label><strong>Auto-Select country</strong><small>Prevents selecting fake countries at registration</small></label>
					<div><select name="set[auto_country]"><option value="0">Disabled</option><option value="1"<?=($config['auto_country'] == 1 ? ' selected' : '')?>>Enabled</option></select></div>
				</div>
				<div class="row">
					<label><strong>1 account per IP</strong></label>
					<div><select name="set[more_per_ip]"><option value="0">Yes</option><option value="1"<?=($config['more_per_ip'] != 0 ? ' selected' : '')?>>No</option></select></div>
				</div>
				<div class="row">
					<label><strong>Email Confirmation</strong></label>
					<div><select name="set[reg_reqmail]"><option value="0">Enabled</option><option value="1"<?=($config['reg_reqmail'] != 0 ? ' selected' : '')?>>Disabled</option></select></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" value="Submit" name="submit" />
				</div>
			</div>
		</form>
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Login Attempts</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>Max login attempts</strong><small>How many times user can try to login before getting blocked!</small></label>
					<div><input type="text" name="set[login_attempts]" value="<?=$config['login_attempts']?>" maxlength="3" required="required" /></div>
				</div>
				<div class="row">
					<label><strong>Login Cooldown</strong><small>How many minutes user must way before he can try again to login!</small></label>
					<div><input type="text" name="set[login_wait_time]" value="<?=$config['login_wait_time']?>" maxlength="3" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" value="Submit" name="submit" />
				</div>
			</div>
		</form>
	</div>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Inactive Users</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>Delete Inactive Users</strong><small>Delete users inactive for X days (0 = disabled)<br />WARNING: You can't restore removed users!</small></label>
					<div><input type="text" name="set[cron_users]" value="<?=$config['cron_users']?>" maxlength="3" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" value="Submit" name="submit" />
				</div>
			</div>
		</form>
		<form method="post" class="box">
			<div class="header">
				<h2>Other Settings</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>Coins on Signup</strong><small>Coins added after registration</small></label>
					<div><input type="text" name="set[reg_coins]" value="<?=$config['reg_coins']?>" required /></div>
				</div>
				<div class="row">
					<label><strong>Cash on Signup</strong><small>Money added after registration</small></label>
					<div><input type="text" name="set[reg_cash]" value="<?=$config['reg_cash']?>" required /></div>
				</div>
				<div class="row">
					<label><strong>Daily clicks limit for free users</strong><small>Set 0 to disable</small></label>
					<div><input type="text" name="set[clicks_limit]" value="<?=$config['clicks_limit']?>" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" value="Submit" name="submit" />
				</div>
			</div>
		</form>
	</div>
</section>