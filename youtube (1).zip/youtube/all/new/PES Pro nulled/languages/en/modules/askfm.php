<?php
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['askfmlike_01'] = 'URL must be something like: http://ask.fm/<b>YOURUSERNAME</b>/answers/<b>ANSWER-ID</b>';
$lang['askfmlike_02'] = 'Ask.fm answer already added!';
$lang['askfmlike_03'] = 'This Ask.fm answer doesn\'t exists!';
$lang['askfmlike_04'] = 'Ask.fm answer was successfully added!';
$lang['askfmlike_05'] = 'Like';
$lang['askfmlike_08'] = 'Like this answer and close opened window...';
$lang['askfmlike_09'] = 'We cannot contact ask.fm...';
$lang['askfmlike_12'] = 'Ask.fm says you haven\'t liked this answer!';

// Add Page
$lang['askfmlike_url'] = 'Answer URL';
$lang['askfmlike_url_desc'] = 'Add your Ask.fm answer url here';
?>