<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['inst_likes_01'] = 'That instagram photo cannot be added!';
$lang['inst_likes_02'] = 'Instagram photo already added!';
$lang['inst_likes_03'] = 'That instagram photo doesn\'t exists!';
$lang['inst_likes_04'] = 'Photo was successfully added!';
$lang['inst_likes_05'] = 'Like';
$lang['inst_likes_08'] = 'Like photo and close opened window...';
$lang['inst_likes_09'] = 'We cannot contact instagram...';
$lang['inst_likes_12'] = 'Instagram says you haven\'t liked that photo!';

// Add Page
$lang['inst_likes_url'] = 'Photo Page URL';
$lang['inst_likes_title'] = 'Title';
$lang['inst_likes_url_desc'] = 'Add your photo page url here';
$lang['inst_likes_title_desc'] = 'Add your photo title here';
?>