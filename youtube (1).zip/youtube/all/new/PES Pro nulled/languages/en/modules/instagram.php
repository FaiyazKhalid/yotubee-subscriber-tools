<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['inst_01'] = 'Private instagram profiles cannot be used in the system!';
$lang['inst_02'] = 'Profile already added!';
$lang['inst_03'] = 'This instagram profile doesn\'t exists!';
$lang['inst_04'] = 'Profile was successfully added!';
$lang['inst_05'] = 'Follow';
$lang['inst_08'] = 'Follow user and close opened window...';
$lang['inst_09'] = 'We cannot contact instagram...';
$lang['inst_12'] = 'Instagram says you aren\'t following this user!';

// Add Page
$lang['inst_url'] = 'Username';
$lang['inst_url_desc'] = 'Add your instagram username here';
?>