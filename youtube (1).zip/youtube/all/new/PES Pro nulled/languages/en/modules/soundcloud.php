<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['scf_01'] = 'Soundcloud Account';
$lang['scf_02'] = 'Soundcloud Username';
$lang['scf_03'] = 'Soundcloud already exist!';
$lang['scf_04'] = 'Soundcloud successfully added!';
$lang['scf_05'] = 'Soundcloud doesn\'t exist!';
$lang['scf_06'] = 'CPC successfully changed!';
$lang['scf_07'] = 'Change CPC';
$lang['scf_08'] = 'Followers received';
$lang['scf_09'] = 'If you don\'t add your real soundcloud username, used on exchange, you can\'t earn coins.';
$lang['scf_10'] = 'Add your Soundcloud account first!';
$lang['scf_11'] = 'Press "Follow" on this page and after that press "Follow" on soundcloud page. After that, press on "Confirm".';
$lang['scf_12'] = 'Follow';
$lang['scf_16'] = 'Follow user and close opened window...';
$lang['scf_17'] = 'We cannot contact Soundcloud...';
$lang['scf_18'] = 'Soundcloud says you aren\'t following this user!';
?>