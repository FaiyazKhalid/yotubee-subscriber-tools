<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['inst_likes_01'] = 'Aceasta fotografie instagram nu poate fi adaugata!';
$lang['inst_likes_02'] = 'Aceasta fotografie a fost deja adaugata!';
$lang['inst_likes_03'] = 'Aceasta fotografie instagram nu exista!';
$lang['inst_likes_04'] = 'Fotografie adaugata cu succes!';
$lang['inst_likes_05'] = 'Like';
$lang['inst_likes_08'] = 'Apreciaza poza si inchide fereastra...';
$lang['inst_likes_09'] = 'Nu ne putem conecta la Instagram...';
$lang['inst_likes_12'] = 'Instagram spune ca nu ai apreciat fotografia!';

// Add Page
$lang['inst_likes_url'] = 'URL Pagina Foto';
$lang['inst_likes_title'] = 'Titlu';
$lang['inst_likes_url_desc'] = 'Adauga link-ul paginii';
$lang['inst_likes_title_desc'] = 'Adauga titlul dorit';
?>