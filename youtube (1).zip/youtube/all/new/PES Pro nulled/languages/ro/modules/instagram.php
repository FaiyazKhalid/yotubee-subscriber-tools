<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['inst_01'] = 'Acest profil de Instagram nu poate fi adaugat!';
$lang['inst_02'] = 'Profilul este deja adaugat!';
$lang['inst_03'] = 'Acest profil de Instagram nu exista!';
$lang['inst_04'] = 'Profilul a fost adaugat cu succes!';
$lang['inst_05'] = 'Urmareste';
$lang['inst_08'] = 'Aboneaza-te si inchide fereastra...';
$lang['inst_09'] = 'Nu ne putem conecta la Instagram...';
$lang['inst_12'] = 'Instagram spune ca nu te-ai abonat la acest utilizator!';

// Add Page
$lang['inst_url'] = 'Nume de Utilizator';
$lang['inst_url_desc'] = 'Adauga numele de utilizator Instagram';
?>