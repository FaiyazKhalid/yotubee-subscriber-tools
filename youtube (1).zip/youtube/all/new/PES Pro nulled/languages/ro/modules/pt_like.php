<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['likepin_01'] = 'URL-ul trebuie sa fie de forma: http://pinterest.com/pin/<b>PIN-ID</b>';
$lang['likepin_02'] = 'Acest pin este deja adaugat!';
$lang['likepin_03'] = 'Acest pin nu exista!';
$lang['likepin_04'] = 'Pin adaugat cu succes!';
$lang['likepin_05'] = 'Like';
$lang['likepin_08'] = 'Apreciaza acest pin apoi inchide pagina deschisa...';
$lang['likepin_09'] = 'Nu ne putem conecta la Pinterest...';
$lang['likepin_12'] = 'Pinterest spune ca nu ai apreciat acest pin!';

// Add Page
$lang['likepin_url'] = 'Pin URL';
$lang['likepin_url_desc'] = 'Adauga URL-ul aici';
?>