<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['retwt_01'] = 'Pagina adaugata cu succes!';
$lang['retwt_02'] = 'Pagina este deja adaugata!';
$lang['retwt_04'] = 'EROARE! Deja distribuit!';

// Add Page
$lang['retwt_url'] = 'URL';
$lang['retwt_title'] = 'Text';
$lang['retwt_url_desc'] = 'Adauga URL-ul paginii';
$lang['retwt_title_desc'] = 'Adaugata un text';
?>