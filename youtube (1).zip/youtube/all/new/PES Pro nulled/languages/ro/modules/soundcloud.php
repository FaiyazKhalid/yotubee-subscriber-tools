<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['scf_01'] = 'Cont Soundcloud';
$lang['scf_02'] = 'Profil Soundcloud';
$lang['scf_03'] = 'Acest cont este deja adaugat!';
$lang['scf_04'] = 'Profilul a fost adaugt cu succes!';
$lang['scf_05'] = 'Acest profil nu exista!';
$lang['scf_06'] = 'CPC modificat cu succes!';
$lang['scf_07'] = 'Modificare CPC';
$lang['scf_08'] = 'Abonati primiti';
$lang['scf_09'] = 'Daca nu adaugi contul real de pe Soundcloud, nu vei putea primi credite.';
$lang['scf_10'] = 'Adauga-ti contul Soundcloud mai intai!';
$lang['scf_11'] = 'Apasa "Follow" pe aceasta pagina, apoi apasa "Follow" pe sounbdcloud si inchide pagina.';
$lang['scf_12'] = 'Follow';
$lang['scf_16'] = 'Aboneaza-te apoi inchide pagina deschisa...';
$lang['scf_17'] = 'Nu ne putem conecta la Soundcloud...';
$lang['scf_18'] = 'Soundcloud spune ca nu te-ai abonat la acest utilizator!';
?>