<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['surf_01'] = 'Website-ul este deja adaugat!';
$lang['surf_02'] = 'Site confirmat cu succes!';
$lang['surf_03'] = 'Site-ul este deja confirmat!';
$lang['surf_04'] = 'Viziteaza';
$lang['surf_07'] = 'Ai vizitat deja aceasta pagina!';
$lang['surf_09'] = 'Vei primi';
$lang['surf_10'] = 'Incepe Navigarea';
$lang['surf_11'] = 'Opreste Navigarea';
$lang['surf_12'] = 'Te rugam sa pastrezi fereastra deschisa, pentru a primi credite!';
$lang['surf_13'] = 'Click pe "Incepe Navigarea" apoi lasa fereastra deschisa.';
$lang['surf_14'] = 'Website adaugat cu succes!';

// Add Page
$lang['surf_url'] = 'URL';
$lang['surf_title'] = 'Titlu';
$lang['surf_url_desc'] = 'Adauga URL-ul paginii';
$lang['surf_title_desc'] = 'Adauga titlul paginii';
?>