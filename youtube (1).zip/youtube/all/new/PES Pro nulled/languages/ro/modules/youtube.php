<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['yt_01'] = 'Video adaugat deja!';
$lang['yt_02'] = 'Te rugam sa adaugi un link valid!';
$lang['yt_03'] = 'Video adaugat cu succes!';
$lang['yt_04'] = 'Urmareste acest video timp de -TIME- secunde, dupa care vei primi -COINS-';
$lang['yt_05'] = 'Trebuie sa vizionezi -TIME- secunde';
$lang['yt_07'] = 'Click aici pentru a viziona alt video';
$lang['yt_08'] = 'Vizioneaza';

// Add Page
$lang['yt_url'] = 'URL Video';
$lang['yt_title'] = 'Titlu Video';
$lang['yt_url_desc'] = 'Adauga URL-ul filmuletului';
$lang['yt_title_desc'] = 'Adauga un titlu';
?>