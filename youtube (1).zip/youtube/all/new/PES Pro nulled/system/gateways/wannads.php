<?php
	define('BASEPATH', true);
	require_once('../init.php');

	// Security Check
	$secret = $db->QueryFetchArray("SELECT config_value FROM `offerwall_config` WHERE `config_name`='wannads_secret'");
	$secret = $secret['config_value'];

	// Get postback
	$userId = isset($_GET['subId']) ? $db->EscapeString($_GET['subId']) : null;
	$survey = isset($_GET['transId']) ? $db->EscapeString($_GET['transId']) : null;
	$points = isset($_GET['reward']) ? $db->EscapeString($_GET['reward']) : null;
    $payout = isset($_GET['payout']) ? $db->EscapeString($_GET['payout']) : null;
	$signature = isset($_GET['signature']) ? $db->EscapeString($_GET['signature']) : null;
	$action = isset($_GET['status']) ? $db->EscapeString($_GET['status']) : null;
	$userIP = isset($_GET['userIp']) ? $db->EscapeString($_GET['userIp']) : '0.0.0.0';
	$country = isset($_GET['country']) ? $db->EscapeString($_GET['country']) : '0.0.0.0';

	// validate signature
	if (md5($userId.$survey.$points.$secret) != $signature){
		echo "ERROR: Signature doesn't match";
		return;
	}

	if(!empty($userId) && $db->QueryGetNumRows("SELECT * FROM `completed_offers` WHERE `survey_id`='".$survey."' LIMIT 1") == 0)
	{
		$user = $db->QueryFetchArray("SELECT `id` FROM `users` WHERE `id`='".$userId."'");
		
		if(!empty($user['id'])) {
			$db->Query("UPDATE `users` SET `coins`=`coins`+'".$points."' WHERE `id`='".$user['id']."'");
			$db->Query("INSERT INTO `users_offers` (`uid`,`total_offers`,`total_coins`,`last_offer`) VALUES ('".$user['id']."','1','".$points."','".time()."') ON DUPLICATE KEY UPDATE `total_offers`=`total_offers`+'1', `total_coins`=`total_coins`+'".$points."', `last_offer`='".time()."'");
			$db->Query("INSERT INTO `completed_offers` (`user_id`,`survey_id`,`user_country`,`user_ip`,`revenue`,`coins`,`method`,`timestamp`) VALUES ('".$user['id']."','".$survey."','".$country."','".ip2long($userIP)."','".$payout."','".$points."','wannads','".time()."')");
		}
		
		echo "OK";
	}
?>