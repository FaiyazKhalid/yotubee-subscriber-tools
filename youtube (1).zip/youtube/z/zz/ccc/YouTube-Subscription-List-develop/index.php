<?php

// PHP - SUBSCRIBER COUNT USING YOUTUBE API V3
// BY @danielsebesta

$api_key = "AIzaSyD1SYxwriSSx4PECgfkFgZegtX1V8Ow6JM";
$channel_id = "UChN9F3ipuGJPOgIysNQAO3g";



$bapi_response = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=snippet&id=' . $channel_id . '&key=' . $api_key . '');
$bapi_response_decoded = json_decode($bapi_response, true);


$bsubscribers = $bapi_response_decoded['items'][0]['snippet']['title'];

$capi_response = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=subscriptions&id=' . $channel_id . '&key=' . $api_key . '');
$capi_response_decoded = json_decode($capi_response, true);


$cbsubscribers = $capi_response_decoded['items'][0]['subscriptions']['subscriptionCount'];



$api_response = file_get_contents('https://www.googleapis.com/youtube/v3/channels?part=statistics&id=' . $channel_id . '&key=' . $api_key . '');
$api_response_decoded = json_decode($api_response, true);

$subscribers = $api_response_decoded['items'][0]['statistics']['subscriberCount'];

echo $subscribers

?>
<br>
<? echo $bsubscribers ?>
<br>
<? echo $csubscribers ?>
