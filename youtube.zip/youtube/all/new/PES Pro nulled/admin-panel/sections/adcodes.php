<?php
	if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

	$message = '';
	if(isset($_POST['ad_add'])) {
		$name = $db->EscapeString($_POST['ad_name']);
		$code = htmlspecialchars(trim($_POST['ad_code']), ENT_QUOTES);
		$size = $db->EscapeString($_POST['ad_size']);
		$status = $db->EscapeString($_POST['ad_status']);
		
		if(empty($name) || empty($code)) {
			$message = '<div class="alert error"><span class="icon"></span><strong>error!</strong> Please complete required fields</div>';
		} else {
			$db->Query("INSERT INTO `ad_codes` (`name`,`code`,`size`,`status`) VALUES ('".$name."','".$code."','".$size."','".$status."')");
			$message = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Advertisment was successfully added</div>';
		}
	}

	if(isset($_GET['del'])) {
		$id = $db->EscapeString($_GET['del']);
		$db->Query("DELETE FROM `ad_codes` WHERE `id`='".$id."'");
	}elseif(isset($_GET['edit'])) {
		$id = $db->EscapeString($_GET['edit']);
		$edit = $db->QueryFetchArray("SELECT * FROM `ad_codes` WHERE `id`='".$id."' LIMIT 1");
		$original_code = htmlspecialchars_decode($edit['code']);
		
		if(isset($_POST['ad_edit'])) {
			$name = $db->EscapeString($_POST['ad_name']);
			$code = htmlspecialchars(trim($_POST['ad_code']));
			$size = $db->EscapeString($_POST['ad_size']);
			$status = $db->EscapeString($_POST['ad_status']);
			
			$db->Query("UPDATE `ad_codes` SET `name`='".$name."', `code`='".$code."', `size`='".$size."' , `status`='".$status."' WHERE `id`='".$id."'");
			$message = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Advertisment was successfully edited</div>';
		}
	}
?>
<section id="content" class="container_12"><?=$message?>
	<div class="grid_8">
		<div class="box">
			<table class="styled">
				<thead>
					<tr>
						<th>ID</th>
						<th>Name</th>
						<th>Code</th>
						<th>Size</th>
						<th>Status</th>
						<th>Actions</th>
					</tr>
				</thead>
				<tbody>
				<?php
				  $advertisments = $db->QueryFetchArrayAll("SELECT * FROM ad_codes ORDER BY id DESC");

				  $j = 0;
				  foreach($advertisments as $advertisment){
					  $j++;
				?>	
					<tr>
						<td><?=$advertisment['id']?></td>
						<td><?=$advertisment['name']?></td>
						<td><?=$advertisment['code']?></td>
						<td><?=($advertisment['size'] == 1 ? '728x90 px' : '428x60 px')?></td>
						<td><?=($advertisment['status'] == 1 ? '<font color="green"><b>Active</b></font>' : '<font color="red"><b>Disabled</b></font>')?></td>
						<td class="center">
							<a href="index.php?x=adcodes&edit=<?=$advertisment['id']?>" class="button small grey tooltip" data-gravity=s title="Edit"><i class="icon-pencil"></i></a>
							<a href="index.php?x=adcodes&del=<?=$advertisment['id']?>" class="button small grey tooltip" data-gravity=s title="Remove"><i class="icon-remove"></i></a>
						</td>
					</tr>
				<?php }?>
				</tbody>
			</table>
		</div>
	</div>
	<div class="grid_4">
		<form method="post" class="box validate">
			<input type="hidden" name="x" value="users" /> 
			<div class="header">
				<h2><?=(isset($_GET['edit']) && !empty($edit['id']) ? 'Edit Advertisment' : 'Add Advertisment')?></h2>
			</div>
			<div class="content">
				<div class="row">
					<label for="ad_name"><strong>Name</strong></label>
					<div>
						<input type="text" value="<?=(isset($_GET['edit']) && !empty($edit['name']) ? $edit['name'] : '')?>" placeholder="Ad Code - 468x60" name="ad_name" id="ad_name" />
					</div>
				</div>
				<div class="row">
					<label for="ad_code"><strong>Code</strong></label>
					<div>
						<textarea class="full-width" rows="4" name="ad_code" id="ad_code" placeholder="Advertisment code" required><?=(isset($_GET['edit']) && !empty($edit['code']) ? $original_code : '')?></textarea>
					</div>
				</div>
				<div class="row">
					<label for="ad_size"><strong>Ad Size</strong></label>
					<div>
						<select name="ad_size" id="ad_size">
							<option value="0">468x60 px</option>
							<option value="1"<?=(isset($_GET['edit']) && $edit['size'] == 1 ? ' selected' : '')?>>728x90 px</option>
						</select>
					</div>
				</div>
				<div class="row">
					<label for="ad_status"><strong>Status</strong></label>
					<div>
						<select name="ad_status" id="ad_status">
							<option value="1">Enabled</option>
							<option value="0"<?=(isset($_GET['edit']) && $edit['status'] == 0 ? ' selected' : '')?>>Disaled</option>
						</select>
					</div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" name="<?=(isset($_GET['edit']) && !empty($edit['id']) ? 'ad_edit' : 'ad_add')?>" value="<?=(isset($_GET['edit']) && !empty($edit['id']) ? 'Edit' : 'Add')?>" />
				</div>
			</div>
		</form>
	</div>
</section>