<?php
	if(! defined('BASEPATH') ){ exit('Unable to view file.'); }
	$reg_today = $db->QueryFetchArray("SELECT COUNT(*) AS `total` FROM `users` WHERE DATE(`signup`) = DATE(NOW())");
	$reg_month = $db->QueryFetchArray("SELECT COUNT(*) AS `total` FROM `users` WHERE MONTH(`signup`) = '".date('m')."' AND YEAR(`signup`) = '".date('Y')."'");
	$online = $db->QueryFetchArray("SELECT COUNT(*) AS `total` FROM `users` WHERE (".time()."-UNIX_TIMESTAMP(`online`)) < 1800");
	$on_today = $db->QueryFetchArray("SELECT COUNT(*) AS `total` FROM `users` WHERE DATE(`online`) = DATE(NOW())");
	$premium = $db->QueryFetchArray("SELECT COUNT(*) AS `total`, SUM(`premium`-'".time()."') AS `premium` FROM `users` WHERE `premium`>'0'");
	$banned = $db->QueryFetchArray("SELECT COUNT(*) AS `total` FROM `users` WHERE `banned`='1'");
	$transactions = $db->QueryFetchArray("SELECT COUNT(CASE WHEN `type`='0' THEN 1 END) AS `coins`, COUNT(CASE WHEN `type`='1' THEN 1 END) AS `vip`, COUNT(CASE WHEN `paid`='0' THEN 1 END) AS `waiting` FROM `transactions`");
	$reports = $db->QueryFetchArray("SELECT COUNT(CASE WHEN `status`>'0' THEN 1 END) AS `checked`, COUNT(CASE WHEN `status`='0' THEN 1 END) AS `unchecked` FROM `reports`");
	$today_click = $db->QueryFetchArray("SELECT SUM(`today_clicks`) AS `today` FROM `user_clicks` WHERE `today_clicks`>'0'");
	$total_clicks = $db->QueryFetchArray("SELECT SUM(`value`) AS `total` FROM `web_stats`");
	$offers_income = $db->QueryFetchArray("SELECT SUM(`revenue`) AS `money`, COUNT(*) AS `total` FROM `completed_offers`");

	// Mining Module Stats
	$mining_stats = $db->QueryFetchArray("SELECT SUM(`total_minutes`) AS `total_min`, SUM(`today_minutes`) AS `today_min`, SUM(`total_coins`) AS `coins` FROM `users_mining`");
	$mining_users = $db->QueryFetchArray("SELECT COUNT(*) AS `total` FROM `users_mining` WHERE `last_activity` >= '".(time()-70)."'");

	// Last 7 days
	$stats_reg = $db->QueryFetchArrayAll("SELECT COUNT(*) AS `total`, DATE(`signup`) AS `day` FROM `users` GROUP BY `day` ORDER BY `day` DESC LIMIT 7");
	$stats_del= $db->QueryFetchArrayAll("SELECT COUNT(*) AS `total`, DATE(`time`) AS `day` FROM `users_deleted` GROUP BY `day` ORDER BY `day` DESC LIMIT 7");
	$stats_log= $db->QueryFetchArrayAll("SELECT COUNT(DISTINCT `uid`) AS `total`, DATE(`time`) AS `day` FROM `user_logins` GROUP BY `day` ORDER BY `day` DESC LIMIT 7");
	
	$dates = array();
	for ($i = 0; $i < 7; $i++) {
		$dates[] = date('Y-m-d', time() - 86400 * $i);
	}
	$dates = array_reverse($dates);

	$rStats = '';
	$j = 0;
	foreach($dates as $date) {
		$registered = 0;
		$deleted = 0;
		$j++;
		foreach($stats_reg as $stat) {
			if($date == $stat['day']) {
				$registered = $stat['total'];
			}
		}
		
		foreach($stats_del as $stat) {
			if($date == $stat['day']) {
				$deleted = $stat['total'];
			}
		}
		
		foreach($stats_log as $stat) {
			if($date == $stat['day']) {
				$logins = $stat['total'];
			}
		}

		$rStatsT .= '<th>'.$date.'</th>';
		$rStatsU .= '<td>'.$registered.'</td>';
		$rStatsD .= '<td>'.$deleted.'</td>';
		$rStatsL .= '<td>'.$logins.'</td>';
	}
	
	if($config['allow_withdraw'] == 1){
		$waiting = $db->QueryFetchArray("SELECT COUNT(*) AS `total`, SUM(`amount`) AS `amount` FROM `requests` WHERE `paid`='0'");
		$paid = $db->QueryFetchArray("SELECT COUNT(*) AS `total`, SUM(`amount`) AS `amount` FROM `requests` WHERE `paid`='1'");
		$rejected = $db->QueryFetchArray("SELECT COUNT(*) AS `total`, SUM(`amount`) AS `amount` FROM `requests` WHERE `paid`='2'");
	}

	$users = $db->QueryFetchArray("SELECT COUNT(`id`) AS `users`, SUM(`coins`) AS `coins`, SUM(`account_balance`) AS `cash` FROM `users`");
	$total_vip = round(($premium['premium']/86400), 0);

	$total_income = $db->QueryFetchArray("SELECT SUM(money) AS money FROM transactions");
	$total_income = (!empty($total_income['money']) ? $total_income['money'] : 0);
	$income_month = $db->QueryFetchArray("SELECT SUM(money) AS money FROM transactions WHERE MONTH(date) = '".date('m')."' AND YEAR(date) = '".date('Y')."'");
	$income_month = (!empty($income_month['money']) ? $income_month['money'] : 0);
	$income_today = $db->QueryFetchArray("SELECT SUM(money) AS money FROM transactions WHERE DATE(date) = DATE(NOW())");
	$income_today = (!empty($income_today['money']) ? $income_today['money'] : 0);
?>
<section id="content" class="container_12 clearfix" data-sort=true>
	<ul class="stats not-on-phone">
		<li>
			<strong><?=number_format($users['users'])?></strong>
			<small>Total Users</small>
			<span <?=($reg_today['total'] > 0 ? 'class="green" ' : '')?>style="margin:4px 0 -10px 0"><?=$reg_today['total']?> today</span>
		</li>
		<li>
			<strong><?=number_format($on_today['total'])?></strong>
			<small>Active Today</small>
		</li>
		<li>
			<strong><?=number_format($transactions['coins']+$transactions['vip'])?></strong>
			<small>Total Sales</small>
			<span <?=($transactions['waiting'] > 0 ? 'class="green" ' : '')?>style="margin:4px 0 -10px 0"><?=$transactions['waiting']?> waiting</span>
		</li>
		<li>
			<strong>~<?=get_currency_symbol($config['currency_code']).number_format($offers_income['money'], 2)?></strong>
			<small>Offers Income</small>
			<span class="green" style="margin:4px 0 -10px 0"><?=number_format($offers_income['total'])?> offers completed</span>
		</li>
		<li>
			<strong><?=number_format(hook_filter('tot_sites',""))?></strong>
			<small>Total Pages</small>
		</li>
		<li>
			<strong><?=number_format($total_clicks['total'])?></strong>
			<small>Total Clicks</small>
			<span <?=($today_click['today'] > 0 ? 'class="green" ' : '')?>style="margin:4px 0 -10px 0"><?=number_format($today_click['today'])?> today</span>
		</li>
	</ul>

	<div class="alert note" id="version_alert" style="margin-top:10px;padding-top:10px;padding-bottom:10px;font-size:14px;text-align:center;display:none"><a href="https://mn-shop.com/account/download" target="_blank"><strong>There is a new version of this script available for download! Download latest version from MN-Shop.com</strong></a></div>

	<h1 class="grid_12 margin-top">Dashboard</h1>
	<div class="grid_7">
		<div class="box">
			<div class="header">
				<h2><img class="icon" src="img/icons/packs/fugue/16x16/users.png" width="16" height="16">Users statistics</h2>
			</div>
			<div class="content">
				<div class="spacer"></div>
				<div class="full-stats">
					<div class="stat hlist" data-list='[{"val":<?=$online['total'].','.($online['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Online Users","color":"green"},{"val":<?=$premium['total'].','.($premium['total'] > 999 ? '"format":"0,0",' : '')?>"title":"VIP Users"},{"val":<?=$banned['total'].','.($banned['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Banned Users","color":"red"},{"val":<?=$reg_today['total'].','.($reg_today['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Registered Today"}]' data-flexiwidth=true></div>
				</div>
			</div>
		</div>
		<div class="box">
			<div class="header">
				<h2><img class="icon" src="img/icons/packs/fugue/16x16/dashboard.png" width="16" height="16">Other statistics</h2>
			</div>
			<div class="content">
				<div class="spacer"></div>
				<div class="full-stats">
					<div class="stat hlist" data-list='[{"val":<?=$users['coins'].','.($users['coins'] > 999 ? '"format":"0,0",' : '')?>"title":"Total Coins"},{"val":<?=$total_vip.','.($total_vip > 999 ? '"format":"0,0",' : '')?>"title":"Total VIP Days","color":"red"},{"val":<?=$users['cash']?>,"format":"<?=get_currency_symbol($config['currency_code'])?>0.00","title":"Account Balances","color":"green"}]' data-flexiwidth=true></div>
				</div>
			</div>
		</div>
	</div>
	<div class="grid_5">
		<div class="box">
			<div class="header">
				<h2><img class="icon" src="img/icons/packs/fugue/16x16/users.png" width="16" height="16">Users activity in past 7 days</h2>
			</div>
			<div class="content">
				<table class="chart" data-type="bars" style="height: 270px;">
					<thead>
						<tr>
							<th></th>
							<?=$rStatsT?>
						</tr>
					</thead>
					<tbody>
						<tr>
							<th>Registered Users</th>
							<?=$rStatsU?>
						</tr>
						<tr>
							<th>Deleted Users</th>
							<?=$rStatsD?>
						</tr>
						<tr>
							<th>Active Users</th>
							<?=$rStatsL?>
						</tr>
					</tbody>	
				</table>
			</div>
		</div>
	</div>
	<div class="grid_6">
		<div class="box">
			<div class="header">
				<h2><img class="icon" src="img/icons/packs/fugue/16x16/coins.png" width="16" height="16">Sales statistics</h2>
			</div>
			<div class="content">
				<div class="spacer"></div>
				<div class="full-stats">
					<div class="stat hlist" data-list='[{"val":<?=$income_today?>,"format":"<?=get_currency_symbol($config['currency_code'])?>0.00","title":"Today Income","color":"green"},{"val":<?=$income_month?>,"format":"<?=get_currency_symbol($config['currency_code'])?>0.00","title":"This Month"},{"val":<?=($total_income)?>,"format":"<?=get_currency_symbol($config['currency_code'])?>0.00","title":"Total Income","color":"red"}]' data-flexiwidth=true></div>
				</div>
			</div>
		</div>
	</div>
	<div class="grid_6">
		<div class="box">
			<div class="header">
				<h2><img class="icon" src="img/icons/report.png" width="16" height="16">Reports</h2>
			</div>
			<div class="content">
				<div class="spacer"></div>
				<div class="full-stats">
					<div class="stat hlist" data-list='[{"val":<?=$reports['unchecked'].','.($reports['unchecked'] > 999 ? '"format":"0,0",' : '')?>"title":"Waiting"},{"val":<?=$reports['checked'].','.($reports['checked'] > 999 ? '"format":"0,0",' : '')?>"title":"Checked","color":"green"}]' data-flexiwidth=true></div>
				</div>
			</div>
		</div>
	</div>
	<?php if(!empty($config['cm_id']) && !empty($config['cm_key']) && !empty($config['cm_domain']) && !empty($config['cm_token'])){ ?>
		<div class="grid_8">
			<div class="box">
				<div class="header">
					<h2><img class="icon" src="img/icons/packs/fugue/16x16/mining.png" width="16" height="16">Mining Stats</h2>
				</div>
				<div class="content">
					<div class="spacer"></div>
					<div class="full-stats">
						<div class="stat hlist" data-list='[{"val":<?=$mining_users['total'].','.($mining_users['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Active Users","color":"green"},{"val":<?=$mining_stats['today_min'].','.($mining_stats['today_min'] > 999 ? '"format":"0,0",' : '')?>"title":"Today Minutes","color":"red"},{"val":<?=$mining_stats['total_min'].','.($mining_stats['total_min'] > 999 ? '"format":"0,0",' : '')?>"title":"Total Minutes","color":"red"},{"val":<?=$mining_stats['coins'].','.($mining_stats['coins'] > 999 ? '"format":"0,0",' : '')?>"title":"Total Coins"}]' data-flexiwidth=true></div>
					</div>
				</div>
			</div>
		</div>
		<div class="grid_4">
			<div class="box">
				<div class="header">
					<h2><img class="icon" src="img/icons/packs/fugue/16x16/jobs.png" width="16" height="16">Completed Offers</h2>
				</div>
				<div class="content">
					<div class="spacer"></div>
					<div class="full-stats">
						<div class="stat hlist" data-list='[{"val":<?=number_format($offers_income['total']).','.($offers_income['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Completed Offers"},{"val":<?=number_format($offers_income['money'], 2)?>,"format":"~<?=get_currency_symbol($config['currency_code'])?>0.00","title":"Offers Income","color":"green"}]' data-flexiwidth=true></div>
					</div>
				</div>
			</div>
		</div>
	<?php } else { ?>
		<div class="grid_12">
			<div class="alert note" style="margin:-5px 0 20px"><a href="http://buy.cashmining.xyz" target="_blank"><span class="icon"></span><strong>To enable Mining System and see stats about this system, you have to purchase CashMining system from Buy.CashMining.xyz then integrate it!</strong></a></div>
		</div>
	<?php } ?>
	<?php if($config['allow_withdraw'] == 1){ ?>
	<div class="grid_12">
		<div class="box">
			<div class="header">
				<h2><img class="icon" src="img/icons/packs/fugue/16x16/orders.png" width="16" height="16">Payment Requests</h2>
			</div>
			<div class="content">
				<div class="spacer"></div>
				<div class="full-stats">
					<div class="stat hlist" data-list='[{"val":<?=$waiting['total'].','.($waiting['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Waiting"},{"val":<?=$paid['total'].','.($paid['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Paid","color":"green"},{"val":<?=$rejected['total'].','.($rejected['total'] > 999 ? '"format":"0,0",' : '')?>"title":"Rejected","color":"red"}]' data-flexiwidth=true></div>
				</div>
				<div class="full-stats">
					<div class="stat hlist" data-list='[{"val":"<?=number_format($waiting['amount'], 2, '.', '')?>","format":"<?=get_currency_symbol($config['currency_code'])?>0.00","title":"Total Waiting"},{"val":"<?=number_format($paid['amount'], 2, '.', '')?>","format":"<?=get_currency_symbol($config['currency_code'])?>0.00","title":"Total Paid","color":"green"},{"val":"<?=number_format($rejected['amount'], 2, '.', '')?>","format":"<?=get_currency_symbol($config['currency_code'])?>0.00","title":"Total Rejected","color":"red"}]' data-flexiwidth=true></div>
				</div>
			</div>
		</div>
	</div>
	<?php } ?>
	<div class="grid_12">
		<div class="box">
			<div class="header">
				<h2><img class="icon" src="img/icons/packs/fugue/16x16/pages.png" width="16" height="16">Modules statistics</h2>
			</div>
			<div class="content">
				<div class="spacer"></div>
				<?php
					foreach($module_list as $module)
					{  
						$name = hook_filter($module.'_info', 'name');
						$table = hook_filter($module.'_info', 'db'); 
						
						if($table != 'db')
						{
							$clicks = $db->FetchArray($db->Query("SELECT value FROM `web_stats` WHERE `module_id`='".$module."'"));
							$clicks = ($clicks['value'] > 0 ? $clicks['value'] : 0);
							$today_clicks = $db->QueryFetchArray("SELECT SUM(today_clicks) AS value FROM `user_clicks` WHERE `module`='".$module."'");
							$today_clicks = ($today_clicks['value'] > 0 ? $today_clicks['value'] : 0);
							$pages = $db->QueryGetNumRows("SELECT id FROM `".$table."`");

							echo '<div class="full-stats" style="min-width:228px">
											<h2 class="center">'.$name.'</h2>
											<div class="stat list" data-list=\'[{"val":'.$pages.',"format":"'.($pages >= 1000 ? '0,0' : '0').'","title":"Pages"},{"val":'.$clicks.',"format":"'.($clicks >= 1000 ? '0,0' : '0').'","title":"Total Clicks"},{"val":'.$today_clicks.',"format":"'.($today_clicks >= 1000 ? '0,0' : '0').'","title":"Today Clicks"}]\'></div>
										</div>';
						}
					}
				?>
			</div>
		</div>
	</div>
</section>