<?php
	if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

	/* Load offerwall settings */
	$ow_config = array();
	$ow_configs = $db->QueryFetchArrayAll("SELECT config_name,config_value FROM `offerwall_config`");
	foreach ($ow_configs as $con)
	{
		$ow_config[$con['config_name']] = $con['config_value'];
	}
	unset($ow_configs); 

	if(empty($ow_config['mtt_hash']))
	{
		$ow_config['mtt_hash'] = md5(GenerateKey(9));
		$db->Query("UPDATE `offerwall_config` SET `config_value`='".$ow_config['mtt_hash']."' WHERE `config_name`='mtt_hash'");
	}

	$message = '';
	if(isset($_POST['edit_offerwall'])){
		$posts = $db->EscapeString($_POST['set']);
		foreach ($posts as $key => $value){
			if($ow_config[$key] != $value){
				$db->Query("UPDATE `offerwall_config` SET `config_value`='".$value."' WHERE `config_name`='".$key."'");
				$ow_config[$key] = $value;
			}
		}
		
		$message = '<div class="alert success"><span class="icon"></span><strong>Success!</strong> Settings successfully changed</div>';
	}
?>
<section id="content" class="container_12"><?=$message?>
	<div class="grid_6">
		<form action="" method="post" class="box">
			<div class="header">
				<h2>BitsWall Settings</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>API Key</strong></label>
					<div><input type="text" name="set[bitswall_key]" value="<?=$ow_config['bitswall_key']?>" required="required" /></div>
				</div>
				<div class="row">
					<label><strong>Secret Key</strong></label>
					<div><input type="text" name="set[bitswall_secret]" value="<?=$ow_config['bitswall_secret']?>" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" name="edit_offerwall" value="Submit" />
				</div>
			</div>
		</form>
		<form action="" method="post" class="box">
			<div class="header">
				<h2>AdWorkMedia Settings</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>App ID</strong><small>SuperRewards Hash Key</small></label>
					<div><input type="text" name="set[adwork_id]" value="<?=$ow_config['adwork_id']?>" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" name="edit_offerwall" value="Submit" />
				</div>
			</div>
		</form>
		<form action="" method="post" class="box">
			<div class="header">
				<h2>KiwiWall Settings</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>Offer Wall ID</strong><small>Kiwiwall Offer Wall ID</small></label>
					<div><input type="text" name="set[kiwiwall_id]" value="<?=$ow_config['kiwiwall_id']?>" required="required" /></div>
				</div>
				<div class="row">
					<label><strong>App Secret</strong><small>Matomy App Secret Key</small></label>
					<div><input type="text" name="set[kiwiwall_secret]" value="<?=$ow_config['kiwiwall_secret']?>" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" name="edit_offerwall" value="Submit" />
				</div>
			</div>
		</form>
		<form action="" method="post" class="box">
			<div class="header">
				<h2>Wannads Settings</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>API Key</strong><small>Wannads API Key</small></label>
					<div><input type="text" name="set[wannads_key]" value="<?=$ow_config['wannads_key']?>" required="required" /></div>
				</div>
				<div class="row">
					<label><strong>Secret</strong><small>Wannads Secret Key</small></label>
					<div><input type="text" name="set[wannads_secret]" value="<?=$ow_config['wannads_secret']?>" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" name="edit_offerwall" value="Submit" />
				</div>
			</div>
		</form>
		<form action="" method="post" class="box">
			<div class="header">
				<h2>JungleOfferWall Settings</h2>
			</div>
			<div class="content">
				<div class="row">
					<label><strong>Offer URL</strong></label>
					<div><input type="text" name="set[mtt_url]" value="<?=$ow_config['mtt_url']?>" placeholder="https://jungleofferwall.com/offerwall/[YOUR-WEBSITE-ID]/" required="required" /></div>
				</div>
				<div class="row">
					<label><strong>Reward to Users</strong><small>How many credits for $1</small></label>
					<div><input type="text" name="set[mtt_reward]" value="<?=$ow_config['mtt_reward']?>" placeholder="25" required="required" /></div>
				</div>
			</div>
			<div class="actions">
				<div class="right">
					<input type="submit" name="edit_offerwall" value="Submit" />
				</div>
			</div>
		</form>
	</div>
	<div class="grid_6">
		<div class="box">
			<div class="header">
				<h2>BitsWall Instructions</h2>
			</div>
			<div class="content">
				<p><b>1)</b> Go to <a href="https://bitswall.net/?ref=er4fd11qw8" target="_blank">BitsWall</a> and create an account (or login if you're already registered).</p>
				<p><b>2)</b> Go to <i>Add Website</i> and configure your new offer wall as you wish.</p>
				<p><b>3)</b> When you create your new offer wall, at step 2, complete the Postback URL with:<br />
					<input type="text" value="<?php echo $config['site_url']; ?>/system/gateways/bitswall.php" onclick="select()" style="width:100%" />
				</p>
				<p><b>4)</b> At step 3 you will find <i>API Key</i> and <i>Secret Key</i>, required to configure your new offer wall.</p>
			</div>
		</div>
		<div class="box">
			<div class="header">
				<h2>AdWorkMedia Instructions</h2>
			</div>
			<div class="content">
				<p><b>1)</b> Go to <a href="http://www.adworkmedia.com/affiliate-publisher.php?ref=82695l" target="_blank">AdWorkMedia</a> and create an account (or login if you're already registered).</p>
				<p><b>2)</b> Go to <i>Tools</i> -> <i>Postback Services</i> -> <i>Add Global Postback</i> and make sure you place URL from bellow at <i>Add New Postback URL</i>
					<input type="text" value="<?php echo $config['site_url']; ?>/system/gateways/adworkmedia.php" onclick="select()" style="width:100%" />
				</p>
				<p><b>3)</b> Go to <i>Tools</i> -> <i>Offer Wall</i> -> <i>New Offer Wall</i> and configure your new offer wall as you wish, but make sure at <i>General Settings</i> -> <i>Postback Site Profile</i> you choose postback created before.</p>
				<p><b>4)</b> Copy Offer Wall ID from Direct Link (last 3-4 characters from URL, <a href="<?php echo $config['site_url']; ?>/admin-panel/img/info/adworkmedia.jpg" target="_blank">click here for example</a>).</p>
			</div>
		</div>
		<div class="box">
			<div class="header">
				<h2>Kiwiwall Instructions</h2>
			</div>
			<div class="content">
				<p><b>1)</b> Go to <a href="https://www.kiwiwall.com/" target="_blank">Kiwiwall</a> and create an account (or login if you're already registered).</p>
				<p><b>2)</b> Go to <i>Apps</i> -> <i><a href="https://www.kiwiwall.com/apps/create" target="_blank">New App</a></i> and make sure you place URL from bellow at <i>Postback URL</i>
					<input type="text" value="<?php echo $config['site_url']; ?>/system/gateways/kiwiwall.php" onclick="select()" style="width:100%" />
				</p>
				<p><b>3)</b> Copy Offer Wall ID from iFrame Code (last 3-4 characters from URL, <a href="<?php echo $config['site_url']; ?>/admin-panel/img/info/kiwiwall.jpg" target="_blank">click here for example</a>) and <i>Secret Key</i>.</p>
			</div>
		</div>
		<div class="box">
			<div class="header">
				<h2>Wannads Instructions</h2>
			</div>
			<div class="content">
				<p><b>1)</b> Go to <a href="https://www.wannads.com" target="_blank">Wannads</a> and create an account (or login if you're already registered).</p>
				<p><b>2)</b> Go to <i>Apps</i> -> <i>Create App</i> and make sure you place URL from bellow at <i>Postback URL</i>
					<input type="text" value="<?php echo $config['site_url']; ?>/system/gateways/wannads.php" onclick="select()" style="width:100%" />
				</p>
				<p><b>3)</b> When you finish you will find API Key and Secret Key.</p>
			</div>
		</div>
		<div class="box">
			<div class="header">
				<h2>JungleOfferWall Instructions</h2>
			</div>
			<div class="content">
				<p><b>1)</b> Go to <a href="https://moretvtime.mn-shop.com/" target="_blank">Integration Request Page</a> and complete this form with required info. Please make sure you complete following Postback:</p>
				<p>
					<input type="text" value="<?php echo $config['site_url']; ?>/system/gateways/jungle.php?hash=<?php echo $ow_config['mtt_hash']; ?>&user_id=[USER_ID]&payout=[PAYOUT]" onclick="select()" style="width:100%" />
				</p>
				<p><b>2)</b> After you send your integration request, it takes up to 24 hours to get an answer, so please check your mailbox.</p>
				<p><b>3)</b> After you receive your offer URL by email, complete <i>Offer URL</i> field. Your offer URL should look like this: https://jungleofferwall.com/offerwall/[YOUR-WEBSITE-ID]/</p>
			</div>
		</div>
	</div>
</section>