<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['soundcloud_likes_01'] = 'This track is already added!';
$lang['soundcloud_likes_02'] = 'This track is not valid or doesn\'t exists!';
$lang['soundcloud_likes_03'] = 'Track was successfully added!';
$lang['soundcloud_likes_04'] = 'URL must be something like: https://soundcloud.com/<b>USERNAME</b>/<b>TRACK-TITLE</b>';
$lang['soundcloud_likes_05'] = 'Like';
$lang['soundcloud_likes_06'] = 'Like this track and close opened window...';
$lang['soundcloud_likes_07'] = 'We cannot contact Soundcloud...';
$lang['soundcloud_likes_08'] = 'Soundcloud says you haven\'t liked that track!.';

// Add Page
$lang['soundcloud_likes_url'] = 'Track URL';
$lang['soundcloud_likes_url_desc'] = 'Add your track url here';
$lang['soundcloud_likes_title'] = 'Track Title';
$lang['soundcloud_likes_title_desc'] = 'Add your track title here';
?>