<?php
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['scp_01'] = 'Soundcloud track already added!';
$lang['scp_02'] = 'Please enter a valid Soundcloud link!';
$lang['scp_03'] = 'Soundcloud track added successfully!';
$lang['scp_04'] = 'Listen this track for at least -TIME- seconds and you will receive -COINS-';
$lang['scp_05'] = 'Must play for -TIME- seconds';
$lang['scp_07'] = 'Click here to listen another track';
$lang['scp_08'] = 'Listen Track';

// Add Page
$lang['scp_url'] = 'Track URL';
$lang['scp_title'] = 'Track Title';
$lang['scp_url_desc'] = 'Add your track url here';
$lang['scp_title_desc'] = 'Add your track title here';
?>