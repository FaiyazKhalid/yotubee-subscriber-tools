<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['ylike_01'] = 'Video already added!';
$lang['ylike_02'] = 'Please enter a valid Youtube link!';
$lang['ylike_03'] = 'Video added successfully!';
$lang['ylike_04'] = 'Press "Like" on the video, then press "Like" on Youtube\'s page. After that, press "Confirm".';
$lang['ylike_05'] = 'Like';
$lang['ylike_09'] = 'Like video and close opened window...';
$lang['ylike_10'] = 'We cannot contact Youtube...';
$lang['ylike_11'] = 'Youtube says you aren\'t liked this video!';
$lang['ylike_14'] = '<b>ERROR:</b> "Likes" feature must be enabled if you want to add this video!';
$lang['ylike_15'] = 'YouTube account';
$lang['ylike_16'] = 'You have to attach your YouTube profile in order to be able to earn coins for video likes exchange. Attached account must be the same account used to add like videos.';
$lang['ylike_17'] = 'YouTube Username';
$lang['ylike_18'] = '<b>ERROR:</b> This Youtube account doesn\'t exists!';

// Add Page
$lang['ylike_url'] = 'Video URL';
$lang['ylike_title'] = 'Video Title';
$lang['ylike_url_desc'] = 'Add your video url here';
$lang['ylike_title_desc'] = 'Add your video title here';
?>