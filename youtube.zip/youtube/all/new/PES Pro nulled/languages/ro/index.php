<?php
/* Romanian language pack for PES Pro */
$c_lang['active'] = '1'; // Set 0 to disable this language

$c_lang['lang'] 	= 'Romana';
$c_lang['code'] 	= 'ro';
$c_lang['vers'] 	= '3.0.0';
$c_lang['charset'] 	= 'UTF-8';

// Do no edit these lines
$c_lang[$c_lang['code'].'_charset'] = $c_lang['charset'];
?>