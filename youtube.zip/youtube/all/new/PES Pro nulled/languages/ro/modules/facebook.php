<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['fb_01'] = 'Nu puteti adauga poze Facebook!';
$lang['fb_02'] = 'Pagina adauga cu succes!';
$lang['fb_05'] = 'Pagina este deja adaugata!';
$lang['fb_06'] = 'EROARE! Trebuie sa fi conectat pentru a primi credite!';
$lang['fb_07'] = 'Apasa click pe Like, apoi inchide pagina deschisa...';
$lang['fb_08'] = 'Nu ne putem conecta la Facebook...';
$lang['fb_09'] = 'Facebook spune ca nu ai dat like la aceasta pagina!';
$lang['fb_12'] = 'Like';
$lang['fb_15'] = '<b>EROARE:</b> Aceasta pagina de facebook nu poate fi utilizata in sistemul nostru!';

// Add Page
$lang['fb_url'] = 'URL';
$lang['fb_title'] = 'Titlu';
$lang['fb_url_desc'] = 'Adauga URL-ul paginii';
$lang['fb_title_desc'] = 'Adauga titlul paginii';
?>