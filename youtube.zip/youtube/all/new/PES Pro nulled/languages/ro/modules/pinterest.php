<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['pin_01'] = 'URL-ul trebuie sa fie de forma: http://pinterest.com/<b>USERNAME</b>';
$lang['pin_02'] = 'Profilul este deja adaugat!';
$lang['pin_03'] = 'Acest profil nu exista!';
$lang['pin_04'] = 'Profil adaugat cu succes!';
$lang['pin_05'] = 'Abonare';
$lang['pin_08'] = 'Aboneaza-te la acest utilizator apoi inchide pagina deschisa...';
$lang['pin_09'] = 'Nu ne putem conecta la Pinterest...';
$lang['pin_12'] = 'Pinterest spune ca nu esti abonat al acestui utilizator!';

// Add Page
$lang['pin_url'] = 'URL Profil';
$lang['pin_url_desc'] = 'Adauga link-ul profilului';
?>