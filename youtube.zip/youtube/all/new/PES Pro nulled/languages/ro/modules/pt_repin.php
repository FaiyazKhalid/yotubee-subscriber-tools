<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['repin_01'] = 'URL-ul trebuie sa fie de forma: http://pinterest.com/pin/<b>PIN-ID</b>';
$lang['repin_02'] = 'Acest pin este deja adaugat!';
$lang['repin_03'] = 'Acest pin nu exista!';
$lang['repin_04'] = 'Pin adaugat cu succes!';
$lang['repin_05'] = 'Repin';
$lang['repin_08'] = 'Reposteaza acest pin apoi inchide pagina deschisa...';
$lang['repin_09'] = 'Nu ne putem conecta la Pinterest...';
$lang['repin_12'] = 'Pinterest spune ca nu ai repostat acest pin!';

// Add Page
$lang['repin_url'] = 'Pin URL';
$lang['repin_url_desc'] = 'Adauga URL-ul paginii';
?>