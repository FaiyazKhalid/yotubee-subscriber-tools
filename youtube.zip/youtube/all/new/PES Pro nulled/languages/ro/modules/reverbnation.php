<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['reverbnation_01'] = 'Acest cont este deja adaugat!';
$lang['reverbnation_02'] = '<b>EROARE:</b> Acest cont nu este valid sau nu exista!';
$lang['reverbnation_03'] = 'Contul a fost adaugat cu succes!';
$lang['reverbnation_04'] = 'http://www.reverbnation.com/fan/USERNAME';
$lang['reverbnation_05'] = 'Fan';
$lang['reverbnation_06'] = '<b>EROARE:</b> Acest cont nu exista!';
$lang['reverbnation_09'] = 'Devin-o fan si inchide pagina...';
$lang['reverbnation_10'] = 'Nu ne putem conecta la Reverbnation...';
$lang['reverbnation_11'] = 'Reverbnation spune ca nu ai devenit fan!';
$lang['reverbnation_14'] = 'Cont Reverbnation';
$lang['reverbnation_15'] = 'Ataseaza-ti contul Reverbnation aici, pentru a putea utiliza acest modul de schimb.';
$lang['reverbnation_16'] = '<b>EROARE:</b> URL-ul trebuie sa fie de forma:';

// Add Page
$lang['reverbnation_url'] = 'URL Pagina';
$lang['reverbnation_title'] = 'Titlu Pagina';
$lang['reverbnation_url_desc'] = 'Adauga link-ul contului aici';
$lang['reverbnation_title_desc'] = 'Adauga titlul aici';
?>