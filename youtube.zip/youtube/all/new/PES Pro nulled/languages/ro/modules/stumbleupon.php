<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['su_01'] = 'URL-ul trebuie sa fie de forma: http://www.stumbleupon.com/stumbler/<b>USERNAME</b>';
$lang['su_02'] = 'Profilul este deja adaugat!';
$lang['su_03'] = 'Profil adaugat cu succes!';
$lang['su_05'] = 'Follow';
$lang['su_08'] = 'Aboneaza-te apoi inchide pagina deschisa...';
$lang['su_09'] = 'Nu ne putem conecta la Stumbleupon...';
$lang['su_10'] = 'Stumble spune ca nu te-ai abonat la acest utilizator!';

// Add Page
$lang['su_url'] = 'URL Profil';
$lang['su_title'] = 'Nume';
$lang['su_url_desc'] = 'Adauga URL-ul profilului';
$lang['su_title_desc'] = 'Adauga numele profilului';
?>