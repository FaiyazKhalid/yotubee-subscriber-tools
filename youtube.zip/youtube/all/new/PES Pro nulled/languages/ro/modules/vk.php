<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['vk_01'] = '<b>EROARE:</b> Aceasta pagina VK nu exista.';
$lang['vk_02'] = 'Pagina adaugata cu succes!';
$lang['vk_05'] = 'Pagina este deja adaugata!';
$lang['vk_06'] = '<b>EROARE:</b> Trebuie sa te conectezi pentru a castiga monede!';
$lang['vk_07'] = 'Aboneaza-te apoi inchide fereastra...';
$lang['vk_08'] = 'Nu ne putem conecta la VK...';
$lang['vk_09'] = 'VK spune ca nu esti abonat al acestei pagini!';
$lang['vk_12'] = 'Follow';
$lang['vk_13'] = '<b>EROARE:</b> Te rugam sa adaugi o adresa VK valida!';

// Add Page
$lang['vk_url'] = 'Nume de Utilizator';
$lang['vk_url_desc'] = 'Adauga username-ul sau ID-ul de pe VK';
?>