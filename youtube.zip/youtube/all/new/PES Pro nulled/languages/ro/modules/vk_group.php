<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['vkg_01'] = '<b>EROARE:</b> Aceast grup VK nu exista.';
$lang['vkg_02'] = 'Grup adaugat cu succes!';
$lang['vkg_05'] = 'Grupul este deja adaugat!';
$lang['vkg_06'] = '<b>EROARE:</b> Trebuie sa te conectezi pentru a castiga monede!';
$lang['vkg_07'] = 'Alatura-te grupului apoi inchide fereastra...';
$lang['vkg_08'] = 'Nu ne putem conecta la VK...';
$lang['vkg_09'] = 'VK spune ca nu faci parte din acest grup!';
$lang['vkg_12'] = 'Join';
$lang['vkg_13'] = '<b>EROARE:</b> Te rugam sa adaugi o adresa VK valida!';

// Add Page
$lang['vkg_url'] = 'Nume de Utilizator';
$lang['vkg_url_desc'] = 'Adauga username-ul sau ID-ul de pe VK';
?>