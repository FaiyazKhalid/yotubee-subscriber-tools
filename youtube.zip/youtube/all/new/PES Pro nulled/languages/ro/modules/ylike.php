<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['ylike_01'] = 'Filmuletul este deja adaugat!';
$lang['ylike_02'] = 'Te rugam sa adaugi un link valid!';
$lang['ylike_03'] = 'Video adaugat cu succes!';
$lang['ylike_04'] = 'Apasa "Like" aici, apoi apasa "Like" pe pagina Youtube apoi inchide fereastra.';
$lang['ylike_05'] = 'Like';
$lang['ylike_09'] = 'Apasa like apoi inchide pagina deschisa...';
$lang['ylike_10'] = 'Nu ne putem conecta la Youtube...';
$lang['ylike_11'] = 'Youtube spune ca nu ai apreciat acest video!';
$lang['ylike_14'] = '<b>EROARE:</b> Acest video are functia "Like-uri" dezactivata!';
$lang['ylike_15'] = 'Cont YouTube';
$lang['ylike_16'] = 'You have to attach your YouTube profile in order to be able to earn coins for video likes exchange. Attached account must be the same account used to add like videos.';
$lang['ylike_17'] = 'Nume de Utilizator';
$lang['ylike_18'] = '<b>EROARE:</b> Acest cont de YouTube nu exista!';

// Add Page
$lang['ylike_url'] = 'URL Video';
$lang['ylike_title'] = 'Titlu Video';
$lang['ylike_url_desc'] = 'Adauga URL-ul filmuletului';
$lang['ylike_title_desc'] = 'Adauga un titlu';
?>