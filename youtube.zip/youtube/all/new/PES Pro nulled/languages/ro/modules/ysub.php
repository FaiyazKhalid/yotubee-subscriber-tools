<?
if(! defined('BASEPATH') ){ exit('Unable to view file.'); }

$lang['ysub_01'] = 'Cont Youtube';
$lang['ysub_02'] = 'Acest cont este deja adaugat!';
$lang['ysub_03'] = 'Cont Youtube adaugat cu succes!';
$lang['ysub_04'] = 'Acest cont nu exista';
$lang['ysub_05'] = 'CPC modificat cu succes!';
$lang['ysub_06'] = 'Modifica CPC';
$lang['ysub_07'] = 'Abonati primiti';
$lang['ysub_08'] = 'Utilizator Youtube';
$lang['ysub_09'] = 'Daca nu adaugi contul real de pe Youtube, nu vei putea primi credite.';
$lang['ysub_10'] = 'Abonati Youtube';
$lang['ysub_11'] = 'Apasa "Abonare" pe aceasta pagina, apoi apasa "Subscribe" pe youtube si inchide pagina deschisa.';
$lang['ysub_12'] = 'Add your Youtube account first!';
$lang['ysub_13'] = 'Abonare';
$lang['ysub_14'] = 'Aboneaza-te la utilizator apoi inchide pagina deschisa...';
$lang['ysub_17'] = 'Youtube spune ca nu esti abonat la acest utilizator!';
?>