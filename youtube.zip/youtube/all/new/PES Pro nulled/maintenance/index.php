<?php
define('BASEPATH', true);
include('../system/init.php');
if($config['maintenance'] == 0){
	redirect('../index.php');
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
	<head><title><?=$config['site_name']?> - Under Construction</title>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<link rel="shortcut icon" type="image/x-icon" href="favicon.ico" />
		<link rel="stylesheet" type="text/css" href="css/style.css" />
        <!--[if lte IE 8]>
        <link rel="stylesheet" type="text/css" href="css/style.ie.css" />
        <![endif]-->
		<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.4.4/jquery.min.js"></script>
		<script type="text/javascript" src="scripts/bar.js"></script>
		<script type="text/javascript">
			$(document).ready(function() {
				$("#pb1").progressBar({ barImage: 'images/progress.png', showText: true} );
			});
		</script>
	</head>
	<body>
		<div class="layer">		
			<div id="main">
				<div class="company_name"><a href="index.php" title="">Under Construction</a></div>
				<!--[if lte IE 8]>
					<div class="light_top"></div>
				<![endif]-->
				<div class="main_box">
					<h1>OUR WEBSITE IS COMING SOON</h1>
					<div class="blackbox">
						<div class="in">
							<div id="bar">
								<div class="progress"><span class="progressBar" id="pb1"><?=$config['m_progress']?>%</span></div>
								<p>We're sorry but we are currently under construction. Check out our progress. Please come back in few minutes.</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>