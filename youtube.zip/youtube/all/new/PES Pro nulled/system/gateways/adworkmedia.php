<?php
define('BASEPATH', true);
require_once('../init.php');

if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {	// Get Real IP				
	$IP = $_SERVER['HTTP_X_FORWARDED_FOR']; 
} else { 
	$IP = $_SERVER['REMOTE_ADDR'];
}	

if ($IP=="67.227.230.75" || $IP=="67.227.230.76") {
	$campaign_id = $db->EscapeString($_GET['campaign_id']);	// Campaign ID
	$country = $db->EscapeString($_GET['country']);				// Country
	$subid = $db->EscapeString($_GET['sid']);	 						// Primary SubID
	$subid2 = $db->EscapeString($_GET['sid2']);  				    // Secondary SubID2
	$subid3 = $db->EscapeString($_GET['sid3']);  					// Secondary SubID3
	$earn = $db->EscapeString($_GET['commission']);				// Commission		
	$status = $db->EscapeString($_GET['status']);  				// Status: 1 (Credited) or 2 (Reversed)
	$userIP = ip2long($_GET['ip']);  											// User IP Address
	$coins = $db->EscapeString($_GET['vc_value']);  				// Virtual Currency Only - VC Ratio * Commission

	if ($status==1) {	
		$user = $db->QueryFetchArray("SELECT * FROM `users` WHERE `id`='".$subid."'");
	
		if(!empty($user['id'])) {
			$db->Query("UPDATE `users` SET `coins`=`coins`+'".$coins."' WHERE `id`='".$user['id']."'");
			$db->Query("INSERT INTO `users_offers` (`uid`,`total_offers`,`total_coins`,`last_offer`) VALUES ('".$user['id']."','1','".$coins."','".time()."') ON DUPLICATE KEY UPDATE `total_offers`=`total_offers`+'1', `total_coins`=`total_coins`+'".$coins."', `last_offer`='".time()."'");
			$db->Query("INSERT INTO `completed_offers` (`user_id`,`survey_id`,`user_country`,`user_ip`,`revenue`,`coins`,`method`,`timestamp`) VALUES ('".$user['id']."','".$campaign_id."','".$country."','".$userIP."','".$earn."','".$coins."','adworkmedia','".time()."')");
		}
	} elseif($status==2) {
		// Status 2 is a Reversal/Chargeback Notification usually due to a fraudulent lead
		// Place Revoke Code Here
		// Subtract a Credit or Points from a user so that you don't lose money for revoked leads	
	}
}
?>