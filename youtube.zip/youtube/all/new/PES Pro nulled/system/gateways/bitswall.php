<?php
	define('BASEPATH', true);
	require('../init.php');

	// Security Check
	$secret = $db->QueryFetchArray("SELECT config_value FROM `offerwall_config` WHERE `config_name`='bitswall_secret'");
	$secret = $secret['config_value'];

	// Get postback
	$userId = isset($_REQUEST['subId']) ? $db->EscapeString($_REQUEST['subId']) : null;
	$survey = isset($_REQUEST['transId']) ? $db->EscapeString($_REQUEST['transId']) : null;
	$reward = isset($_REQUEST['reward']) ? $db->EscapeString($_REQUEST['reward']) : null;
    $payout = isset($_REQUEST['payout']) ? $db->EscapeString($_REQUEST['payout']) : null;
	$action = isset($_REQUEST['status']) ? $db->EscapeString($_REQUEST['status']) : null;
	$userIP = isset($_REQUEST['userIp']) ? $db->EscapeString($_REQUEST['userIp']) : '0.0.0.0';
	$country = isset($_REQUEST['country']) ? $db->EscapeString($_REQUEST['country']) : '0.0.0.0';

	// Validate signature
	if (md5($userId.$survey.$reward.$secret) != $_REQUEST['signature']){
		echo "ERROR: Signature doesn't match";
		return;
	}

	if(!empty($userId) && $db->QueryGetNumRows("SELECT * FROM `completed_offers` WHERE `survey_id`='".$survey."' LIMIT 1") == 0)
	{
		$user = $db->QueryFetchArray("SELECT `id` FROM `users` WHERE `id`='".$userId."'");
		
		if(!empty($user['id'])) {
			$db->Query("UPDATE `users` SET `coins`=`coins`+'".$reward."' WHERE `id`='".$user['id']."'");
			$db->Query("INSERT INTO `users_offers` (`uid`,`total_offers`,`total_coins`,`last_offer`) VALUES ('".$user['id']."','1','".$reward."','".time()."') ON DUPLICATE KEY UPDATE `total_offers`=`total_offers`+'1', `total_coins`=`total_coins`+'".$reward."', `last_offer`='".time()."'");
			$db->Query("INSERT INTO `completed_offers` (`user_id`,`survey_id`,`user_country`,`user_ip`,`revenue`,`coins`,`method`,`timestamp`) VALUES ('".$user['id']."','".$survey."','".$country."','".ip2long($userIP)."','".$payout."','".$reward."','bitswall','".time()."')");
		}
	}

	echo 'ok';
?>