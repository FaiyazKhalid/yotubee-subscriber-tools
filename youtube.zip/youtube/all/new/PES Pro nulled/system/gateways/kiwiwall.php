<?php
  define('BASEPATH', true);
  require_once('../init.php');

  // KiwiWall server IP addresses
  $allowed_ips = array(
      '34.193.235.172'
  );

  // Proceess only requests from KiwiWall IP addresses
  // This is optional validation
  if (!in_array($_SERVER['REMOTE_ADDR'], $allowed_ips)) {
    echo 0;
    die();
  }

  
  // Security Check
  $postback_password = $db->QueryFetchArray("SELECT config_value FROM `offerwall_config` WHERE `config_name`='kiwiwall_secret'");
  $postback_password = $postback_password['config_value'];

  
  // Get parameters
  $status = $_REQUEST['status'];
  $trans_id = $_REQUEST['trans_id'];
  $sub_id = $_REQUEST['sub_id'];
  $sub_id_2 = $_REQUEST['sub_id_2'];
  $gross = $_REQUEST['gross'];
  $coins = $_REQUEST['amount'];
  $offer_id = $_REQUEST['offer_id'];
  $offer_name = $_REQUEST['offer_name'];
  $app_id = $_REQUEST['app_id'];
  $ip_address = $_REQUEST['ip_address'];
  $signature = $_REQUEST['signature'];

  // Create validation signature
  $validation_signature = md5($sub_id . ':' . $coins . ':' . $postback_password);
  if ($signature != $validation_signature) {
    echo 0;
    die();
  }

  if(!empty($sub_id) && $db->QueryGetNumRows("SELECT * FROM `completed_offers` WHERE `survey_id`='".$trans_id."' LIMIT 1") == 0)
  {
    $user = $db->QueryFetchArray("SELECT * FROM `users` WHERE `id`='".$sub_id."'");
    
    if(!empty($user['id'])) {
      $db->Query("UPDATE `users` SET `coins`=`coins`+'".$coins."' WHERE `id`='".$user['id']."'");
      $db->Query("INSERT INTO `users_offers` (`uid`,`total_offers`,`total_coins`,`last_offer`) VALUES ('".$user['id']."','1','".$coins."','".time()."') ON DUPLICATE KEY UPDATE `total_offers`=`total_offers`+'1', `total_coins`=`total_coins`+'".$coins."', `last_offer`='".time()."'");
	  $db->Query("INSERT INTO `completed_offers` (`user_id`,`survey_id`,`user_country`,`user_ip`,`revenue`,`coins`,`method`,`timestamp`) VALUES ('".$user['id']."','".$trans_id."','".$user['country']."','".ip2long($ip_address)."','".$gross."','".$coins."','kiwiwall','".time()."')");

      echo 1;
      die();
    }
  }
  
  echo 0;
  die();
?>