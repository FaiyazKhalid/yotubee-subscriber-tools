<?php
	/* Error Reporting */
	error_reporting(0);
	ini_set('display_errors', 0);

	/* Starting session */
	session_start();

	/* Define Base Path */
	define('BASE_PATH', realpath(dirname(__FILE__).'/..'));

	/* Define Database Extension (MySQL or MySQLi) */
	$config['sql_extenstion']  = 'MySQLi';

	/* Include required files */
	require(BASE_PATH.'/system/database.php');
	require(BASE_PATH.'/system/libs/functions.php');
	require(BASE_PATH.'/system/libs/database/'.$config['sql_extenstion'].'.php');
	include(BASE_PATH.'/system/libs/PHPMailer/load.php');

	/* Database connection */
	$db = new MySQLConnection($config['sql_host'], $config['sql_username'], $config['sql_password'], $config['sql_database']);
	$db->Connect();

	unset($config['sql_password']);

	/* Run first update, before loading settings */
	if(!defined('IS_AJAX') && file_exists(BASE_PATH.'/system/modules/db_update/runFirstUpdate.php')){
		include(BASE_PATH.'/system/modules/db_update/runFirstUpdate.php');
	}

	/* Website settings */
	$config = array();
	$configs = $db->QueryFetchArrayAll("SELECT * FROM `site_config`");
	foreach ($configs as $con)
	{
		$config[$con['config_name']] = $con['config_value']; 
	}

	unset($configs); 

	/* Script Version */
	$config['version'] = '3.2.8';

	/* Website Theme */
	$config['theme'] = (!empty($config['theme']) && file_exists(BASE_PATH.'/template/'.$config['theme'].'/index.php') ? $config['theme'] : 'default');
	include(BASE_PATH.'/template/'.$config['theme'].'/index.php');
	if(defined('IS_ADMIN')){
		$set_def_theme = '';
		foreach(glob(BASE_PATH.'/template/*/index.php') as $tm){
			include($tm);
			
			$selected = (isset($_POST['set']['theme']) && $_POST['set']['theme'] == $theme['code'] ? ' selected' : (!isset($_POST['set']['theme']) && $config['theme'] == $theme['code'] ? ' selected' : '')); 
			$set_def_theme .= '<option value="'.$theme['code'].'"'.$selected.'>'.$theme['name'].'</option>';
		}
	}

	/* Load modules */
	foreach(glob(BASE_PATH.'/system/modules/*/index.php') as $plugin) {  
		include($plugin);  
	}

	/* User Session */
	$is_online = false;
	if(isset($_SESSION['EX_login'])){
		$ses_id = $db->EscapeString($_SESSION['EX_login']);
		$data	= $db->QueryFetchArray("SELECT *,UNIX_TIMESTAMP(`online`) AS `online` FROM `users` WHERE `id`='".$ses_id."' AND `banned`='0' LIMIT 1");
		$is_online = true;
		if(empty($data['id'])){
			session_destroy();
			$is_online = false;
		}elseif($data['online']+60 < time() && !defined('IS_AJAX')){
			$db->Query("UPDATE `users` SET `online`=NOW() WHERE `id`='".$data['id']."'");
			$_SESSION['EX_login'] = $data['id'];
		}
	}elseif(isset($_COOKIE['PESAutoLogin'])){
		$sesCookie = $db->EscapeString($_COOKIE['PESAutoLogin'], 0);

		$ses_user 	= '';
		$ses_hash 	= '';
		$sesCookie_exp = explode('&', $sesCookie);
		foreach($sesCookie_exp as $sesCookie_part){
			$find_ses_exp = explode('=', $sesCookie_part);
			if($find_ses_exp[0] == 'ses_user'){
				$ses_user = $db->EscapeString($find_ses_exp[1]);
			}elseif($find_ses_exp[0] == 'ses_hash'){
				$ses_hash = $db->EscapeString($find_ses_exp[1]);
			}
		}
		
		if(!empty($ses_user) && !empty($ses_hash)){
			$data = $db->QueryFetchArray("SELECT *,UNIX_TIMESTAMP(`online`) AS `online` FROM `users` WHERE (`login`='".$ses_user."' OR `email`='".$ses_user."') AND (`pass`='".$ses_hash."' AND `banned`='0') LIMIT 1");
			if(empty($data['id'])){
				unset($_COOKIE['PESAutoLogin']); 
			}else{
				$_SESSION['EX_login'] = $data['id'];
				$is_online = true;
				
				$check_activity = $db->QueryGetNumRows("SELECT * FROM `user_logins` WHERE `uid`='".$data['id']."' AND DATE(`time`) = DATE(NOW()) LIMIT 1");
				if($check_activity == 0){
					$ip_address = ip2long(VisitorIP());
					$browser = $db->EscapeString($_SERVER['HTTP_USER_AGENT']);
					$db->Query("INSERT INTO `user_logins` (`uid`,`ip`,`info`,`time`) VALUES ('".$data['id']."','".$ip_address."','".$browser."',NOW())");
				}
			}
		}else{
			unset($_COOKIE['PESAutoLogin']); 
		}
	}

	/* Language system */
	$CONF['language'] = ($config['def_lang'] != '' && file_exists('languages/'.$config['def_lang'].'/index.php') ? $config['def_lang'] : 'en');
	if(!defined('IS_AJAX')) {
		$lang_select = '';
		if(defined('IS_ADMIN')){ $set_def_lang = ''; }
		foreach(glob(BASE_PATH.'/languages/*/index.php') as $langname){
			$langarray[] = str_replace(array(BASE_PATH.'/languages/', '/index.php'), '', $langname);
			include($langname);
			
			if(defined('IS_ADMIN')){
				$selected = (isset($_POST['set']['def_lang']) && $_POST['set']['def_lang'] == $c_lang['code'] ? ' selected' : (!isset($_POST['set']['def_lang']) && $config['def_lang'] == $c_lang['code'] ? ' selected' : '')); 
				if($c_lang['active'] != 0){
					$set_def_lang .= '<option value="'.$c_lang['code'].'"'.$selected.'>'.$c_lang['lang'].'</option>';
				}
			}

			if(isset($_GET['peslang'])){
				$selected = ($_GET['peslang'] == $c_lang['code'] ? ' active' : '');
			}elseif(isset($_COOKIE['peslang'])){
				$selected = ($_COOKIE['peslang'] == $c_lang['code'] ? ' active' : '');
			}else{
				$selected = ($CONF['language'] == $c_lang['code'] ? ' active' : '');
			}
			
			if($c_lang['active'] != 0){
				$c_lang['code'] = "'".$c_lang['code']."'";
				$lang_select .= '<a class="dropdown-item'.$selected.'" href="javascript:void(0)" onclick="langSelect('.$c_lang['code'].');">'.$c_lang['lang'].'</a>';
			}
		}
	}

	if(isset($_GET['peslang'])){
		if(in_array($_GET['peslang'], $langarray)){
			setcookie('peslang', $_GET['peslang'], time()+360000);
			$CONF['language'] = $_GET['peslang'];
		}
	} elseif (isset($_COOKIE['peslang']) && $_COOKIE['peslang'] != ''){
		$CONF['language'] = $_COOKIE['peslang'];
	}

	// Load main language
	if($CONF['language'] != 'en') {
		if(file_exists(BASE_PATH.'/languages/en/base/lang.php')){ 
			include(BASE_PATH.'/languages/en/base/lang.php'); 
		}

		if(file_exists(BASE_PATH.'/languages/en/modules')){ 
			foreach(glob(BASE_PATH.'/languages/en/modules/*.php') as $langfile) {  
				include($langfile);  
			}  
		}
	}

	// Load selected language
	foreach(glob(BASE_PATH.'/languages/'.$CONF['language'].'/*/*.php') as $langfile) {  
		include($langfile);  
	}  

	$conf['lang_charset'] = (!empty($c_lang[$CONF['language'].'_charset']) ? $c_lang[$CONF['language'].'_charset'] : 'UTF-8');
	header('Content-type: text/html; charset='.$conf['lang_charset']);

	/* All rights reserved (c) MafiaNet - MN-Shop.com */
?>