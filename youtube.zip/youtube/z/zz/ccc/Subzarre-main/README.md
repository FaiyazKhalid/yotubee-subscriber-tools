# Subzarre
A local database system for maintaining YouTube subscriptions.
