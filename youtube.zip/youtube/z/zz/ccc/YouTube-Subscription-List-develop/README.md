# YouTube Sub List

A tool to aggregate videos from a number of channels and track which you have watched and which are new

# Subscribed Channels

The list of channels you wish to subscribe to is kept in the a file named `channels.json` which should be placed in the root of the project.

There is an example `channels.json.sample` to show the expected format, it's just an array of channel IDs
