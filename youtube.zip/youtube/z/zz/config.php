<?php
/*
 * Database information.
 * All fields are required
 */
//Database host: Most of the time it is 'localhost'
$db_host = 'localhost';
//Database Name: Name of the database which you want to connect whith this application
$db_name = 'advocatespedia_youtube';
//Database Username: Username which have all priviledges to the database that you want to connect
$db_user = 'advocatespedia_youtube';
//Password: Password of the user that you added
$db_pass = '9971217372Fk';
//Youtube Api key
$yt_api = 'AIzaSyCQrth2LVbjl0NpTgst749-Fxf3rmQopMg';


/*
 * Do not modify anything from here
 */
//Database connection: You do not need to change anything here
$link = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
